import assert from "node:assert/strict"
import test from "node:test"

import {
  authoredCheckSummary,
  authoredSuiteCostBudgetContract,
  authoredSuiteRunPreviewIdentity,
  blankEvalScenarioDraft,
  duplicateEvalSuiteCase,
  EVAL_SUITE_MAX_CASES,
  evalSuiteDraftFromDocument,
  evalSuitePreviewMatchesDraft,
  newEvalSuiteDraft,
  newSimpleEvalCase,
  scenarioArtifactBindingsRequireMaterialization,
  validateEvalSuiteDraft,
} from "../src/lib/eval-suite-authoring.ts"

const revision = (digit) => `sha256:${digit.repeat(64)}`

function authoredDocument() {
  return {
    schema_version: 1,
    revision: revision("a"),
    target_key: "assistant.default",
    suite: {
      id: "support-regressions",
      revision: revision("b"),
      name: "Support regressions",
      description: "Reusable support behavior",
      trial_request: { trials: 1, timeout_seconds: 120 },
    },
    cases: [
      {
        revision: revision("c"),
        id: "refund-case",
        name: "Refund case",
        description: null,
        source: null,
        stimulus: {
          kind: "simple_input",
          input: { messages: [{ role: "user", text: "Refund invoice 123." }] },
        },
        assertions: [{ id: "completed", kind: "root_status", expected: "completed" }],
      },
    ],
  }
}

test("new suite and case helpers create complete deterministic drafts", () => {
  const draft = newEvalSuiteDraft("assistant.default")
  assert.equal(draft.schema_version, 3)
  assert.equal(draft.target_key, "assistant.default")
  assert.deepEqual(draft.trial_request, {
    trials: 1,
    timeout_seconds: 300,
    minimum_passed_trials: 1,
    max_concurrency: 1,
  })
  assert.deepEqual(validateEvalSuiteDraft(draft), { ok: true, draft })

  const added = newSimpleEvalCase(draft.cases)
  assert.equal(added.id, "case")
  assert.deepEqual(added.assertions, [
    { id: "root_status", kind: "root_status", expected: "completed" },
  ])

  const duplicate = duplicateEvalSuiteCase([draft.cases[0], added], 0)
  assert.equal(duplicate.id, "case-1-copy")
  duplicate.assertions[0].id = "changed"
  assert.equal(draft.cases[0].assertions[0].id, "root_status")
})

test("saved suite projection is editable without mutating immutable server material", () => {
  const document = authoredDocument()
  const draft = evalSuiteDraftFromDocument(document)

  assert.equal(evalSuitePreviewMatchesDraft(document, draft), true)
  assert.equal("revision" in draft.cases[0], false)
  draft.cases[0].stimulus.input.messages[0].text = "Changed"
  assert.equal(document.cases[0].stimulus.input.messages[0].text, "Refund invoice 123.")
  assert.equal(evalSuitePreviewMatchesDraft(document, draft), false)
})

test("launch preview identity is bound to the exact saved and reviewed suite revision", () => {
  const selection = {
    case_ids: ["refund-case"],
    cost_budget: { max_estimated_cost: "0.10", currency: "USD" },
  }
  const current = authoredSuiteRunPreviewIdentity(revision("a"), revision("a"), selection)

  assert.equal(current, authoredSuiteRunPreviewIdentity(revision("a"), revision("a"), selection))
  assert.notEqual(current, authoredSuiteRunPreviewIdentity(revision("a"), revision("b"), selection))
  assert.notEqual(
    current,
    authoredSuiteRunPreviewIdentity(revision("a"), revision("a"), {
      ...selection,
      cost_budget: { max_estimated_cost: "0.20", currency: "USD" },
    }),
  )
})

test("authored suite candidate budgets require published target pricing", () => {
  const target = { cost_budget_available: true, cost_budget_currencies: ["USD"] }
  assert.deepEqual(authoredSuiteCostBudgetContract("0.10", "usd", target), {
    max_estimated_cost: "0.10",
    currency: "USD",
  })
  assert.equal(authoredSuiteCostBudgetContract("", "USD", target), undefined)
  assert.equal(authoredSuiteCostBudgetContract("0.00", "USD", target), null)
  assert.equal(authoredSuiteCostBudgetContract("-1", "USD", target), null)
  assert.equal(authoredSuiteCostBudgetContract(`1${"0".repeat(64)}`, "USD", target), null)
  assert.equal(authoredSuiteCostBudgetContract("0.10", "EUR", target), null)
  assert.equal(
    authoredSuiteCostBudgetContract("0.10", "USD", {
      cost_budget_available: false,
      cost_budget_currencies: [],
    }),
    null,
  )
})

test("only nonblank embedded artifact overrides require fixture materialization", () => {
  assert.equal(scenarioArtifactBindingsRequireMaterialization({}, true), false)
  assert.equal(
    scenarioArtifactBindingsRequireMaterialization({ "input-file": "  \t" }, true),
    false,
  )
  assert.equal(
    scenarioArtifactBindingsRequireMaterialization({ "input-file": "retained-artifact-123" }, true),
    true,
  )
  assert.equal(
    scenarioArtifactBindingsRequireMaterialization(
      { "input-file": "retained-artifact-123" },
      false,
    ),
    false,
  )
})

test("blank scenario authoring is target-bound and starts with one initial input", () => {
  const evalCase = newEvalSuiteDraft("assistant.default").cases[0]
  const scenario = blankEvalScenarioDraft("assistant.default", evalCase)

  assert.equal(scenario.id, "case-1-scenario")
  assert.equal(scenario.target_key, "assistant.default")
  assert.equal(scenario.events.length, 1)
  assert.equal(scenario.events[0].kind, "initial")
  assert.equal(scenario.events[0].sequence, 0)
})

test("suite validation mirrors Python Unicode whitespace and immutable scenario references", () => {
  const blank = newEvalSuiteDraft("assistant.default")
  blank.cases[0].stimulus.input.messages[0].text = "\u0085"
  assert.match(validateEvalSuiteDraft(blank).error, /must contain/)

  blank.cases[0].stimulus.input.messages[0].text = "\ufeff"
  assert.deepEqual(validateEvalSuiteDraft(blank), { ok: true, draft: blank })

  const outerWhitespace = newEvalSuiteDraft("assistant.default")
  outerWhitespace.name = "\u0085Evaluation suite"
  assert.match(validateEvalSuiteDraft(outerWhitespace).error, /without outer whitespace/)

  const scenario = newEvalSuiteDraft("assistant.default")
  scenario.cases[0].stimulus = {
    kind: "scenario",
    scenario_id: "saved-scenario",
    scenario_revision: "pending",
  }
  assert.match(validateEvalSuiteDraft(scenario).error, /saved immutable scenario revision/)

  const opaque = newEvalSuiteDraft("external.candidate")
  opaque.cases[0].stimulus.input = {
    opaque_external_case_ref: { id: "private-case", revision: revision("d") },
  }
  assert.match(validateEvalSuiteDraft(opaque).error, /runtime-owned opaque external input/)
})

test("suite validation enforces bounded threshold and concurrency settings", () => {
  const threshold = newEvalSuiteDraft("assistant.default")
  threshold.trial_request = {
    trials: 3,
    timeout_seconds: 30,
    minimum_passed_trials: 4,
    max_concurrency: 2,
  }
  assert.match(validateEvalSuiteDraft(threshold).error, /Required passes/)

  const concurrency = newEvalSuiteDraft("assistant.default")
  concurrency.trial_request.max_concurrency = 65
  assert.match(validateEvalSuiteDraft(concurrency).error, /Concurrency/)
})

test("suite validation enforces the server's 1,000-case ceiling", () => {
  const draft = newEvalSuiteDraft("assistant.default")
  draft.cases = Array.from({ length: EVAL_SUITE_MAX_CASES + 1 }, () =>
    structuredClone(draft.cases[0]),
  )

  assert.match(validateEvalSuiteDraft(draft).error, /between 1 and 1,000 cases/)
  assert.throws(
    () => newSimpleEvalCase(draft.cases.slice(0, EVAL_SUITE_MAX_CASES)),
    /cannot contain more than 1000 cases/,
  )
  assert.throws(
    () => duplicateEvalSuiteCase(draft.cases.slice(0, EVAL_SUITE_MAX_CASES), 0),
    /cannot contain more than 1000 cases/,
  )
})

test("authored plain model judges retain their typed rubric and evaluator fields", () => {
  const draft = newEvalSuiteDraft("assistant.default")
  draft.cases[0].assertions = [
    {
      id: "quality",
      kind: "model_judge",
      evaluator_key: "answer-quality",
      rubric: "Explain the answer with evidence.",
      rubric_version: "v1",
      threshold: 0.75,
      include_transcript: true,
    },
  ]
  assert.deepEqual(validateEvalSuiteDraft(draft), { ok: true, draft })
  const document = authoredDocument()
  document.cases[0].assertions = structuredClone(draft.cases[0].assertions)
  assert.deepEqual(
    evalSuiteDraftFromDocument(document).cases[0].assertions,
    draft.cases[0].assertions,
  )
  for (const patch of [
    { threshold: true },
    { threshold: NaN },
    { threshold: null },
    { threshold: 1.1 },
    { include_transcript: "true" },
    { evaluator_key: "" },
    { rubric: " " },
    { rubric_version: "" },
    { rubric: "x".repeat(16_385) },
  ]) {
    const invalid = structuredClone(draft)
    Object.assign(invalid.cases[0].assertions[0], patch)
    assert.equal(validateEvalSuiteDraft(invalid).ok, false, JSON.stringify(patch))
  }
})

test("JSON equality validates its mode and expected JSON without coercing the draft", () => {
  const draft = newEvalSuiteDraft("assistant.default")
  draft.cases[0].assertions = [
    {
      id: "json",
      kind: "final_output_equals",
      comparison: "json",
      expected: '{"ok": true, "count": 1}',
    },
  ]
  assert.deepEqual(validateEvalSuiteDraft(draft), { ok: true, draft })
  for (const patch of [{ expected: "{" }, { comparison: "future" }]) {
    const invalid = structuredClone(draft)
    Object.assign(invalid.cases[0].assertions[0], patch)
    assert.equal(validateEvalSuiteDraft(invalid).ok, false)
  }
  draft.cases[0].assertions[0].comparison = "text"
  draft.cases[0].assertions[0].expected = "{"
  assert.equal(validateEvalSuiteDraft(draft).ok, true)
})

test("check sentences preserve zero limits, ordered calls and JSON comparison meaning", () => {
  assert.equal(
    authoredCheckSummary({
      kind: "tool_called",
      tool_name: "query_ledger",
      min_count: 0,
      max_count: 0,
    }),
    "Calls query_ledger 0 times",
  )
  assert.equal(
    authoredCheckSummary({ kind: "tools_called_in_order", tool_names: ["read", "write", "read"] }),
    "Calls read → write → read",
  )
  assert.equal(
    authoredCheckSummary({ kind: "final_output_equals", expected: "true", comparison: "json" }),
    "Final answer equals JSON true",
  )
  assert.equal(
    authoredCheckSummary({ kind: "max_total_tokens", maximum: 0 }),
    "Uses at most 0 tokens",
  )
  assert.equal(
    authoredCheckSummary({
      kind: "model_judge",
      rubric: "Explains the variance",
      evaluator_key: "quality",
      rubric_version: "v1",
    }),
    "Judge: Explains the variance",
  )
})
