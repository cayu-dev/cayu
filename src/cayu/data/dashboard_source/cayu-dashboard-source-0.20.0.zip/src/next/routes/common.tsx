import { Popover } from "@base-ui/react/popover"
import {
  Link,
  type NavigateOptions,
  type RegisteredRouter,
  useNavigate,
  useRouterState,
} from "@tanstack/react-router"
import { Ellipsis, Menu, PanelLeft } from "lucide-react"
import {
  createContext,
  type MouseEvent,
  type ReactNode,
  type RefObject,
  useContext,
  useLayoutEffect,
  useRef,
} from "react"
import { Button } from "@/components/ui/button"
import { dashboardAsset } from "@/lib/config"
import {
  readingPositionFromScroll,
  readReadingPosition,
  restoreScrollPosition,
  writeReadingPosition,
} from "@/lib/reading-position"
import { cn } from "@/lib/utils"
import type { SessionOverview, SessionState } from "../api/types"
import { STATE_LABEL, shouldFollowRowClick } from "../app/session-model"

/** Keep the registered router's route, parameter and search contracts intact. */
export const NavLink = Link
export const useGo = useNavigate

/**
 * A click handler for a list row whose title cell is a real link: a plain click anywhere
 * on the row navigates, while cmd/ctrl/shift-clicks, middle clicks and clicks on the
 * link itself are left to the browser. Selecting text in the row doesn't navigate.
 */
export function useRowClick() {
  const go = useGo()
  return <const TTo extends string>(options: NavigateOptions<RegisteredRouter, string, TTo>) =>
    (e: MouseEvent<HTMLElement>) => {
      const target = e.target instanceof Element ? e.target : null
      const onControl = !!target?.closest("a, button, input, select, textarea, label, summary")
      if (window.getSelection()?.type === "Range") return
      if (
        shouldFollowRowClick({
          button: e.button,
          metaKey: e.metaKey,
          ctrlKey: e.ctrlKey,
          shiftKey: e.shiftKey,
          altKey: e.altKey,
          defaultPrevented: e.defaultPrevented,
          onControl,
        })
      )
        void go(options)
    }
}

/** Classes for a clickable list row; its title link carries keyboard focus. */
export const ROW_CLASS =
  "cursor-pointer border-b border-border last:border-0 hover:bg-muted/60 focus-within:bg-muted/60"
/** Classes for the title link inside a clickable row. */
export const ROW_LINK_CLASS = "outline-none hover:underline focus-visible:underline"

/** Marks a session that ran as an eval trial, in lists that include them. */
export function EvalTrialTag() {
  return (
    <span
      className="shrink-0 rounded border border-border px-1 text-[10px] text-muted-foreground"
      title="Run by an eval suite (cayu:eval_trial). Left out of counts by default."
    >
      Eval trial
    </span>
  )
}

export const sessionRoute = (id: string) =>
  ({ to: "/sessions/$sessionId", params: { sessionId: id } }) as const
export const taskRoute = (id: string) => ({ to: "/tasks/$taskId", params: { taskId: id } }) as const

/** The Cayu logo: under the dashboard's base path when served by the runtime, next to the page otherwise. */
export const logoUrl = () =>
  window.__CAYU_DASHBOARD_CONFIG__ ? dashboardAsset("logo.svg") : "./logo.svg"

const DOT: Record<SessionState, string> = {
  running: "bg-info animate-pulse motion-reduce:animate-none",
  waiting_approval: "bg-warning",
  waiting_input: "bg-warning",
  needs_recovery: "bg-warning",
  completed: "bg-success",
  failed: "bg-destructive",
  interrupted: "bg-muted-foreground/50",
}
const TEXT: Record<SessionState, string> = {
  running: "text-info",
  waiting_approval: "text-warning",
  waiting_input: "text-warning",
  needs_recovery: "text-warning",
  completed: "text-success",
  failed: "text-destructive",
  interrupted: "text-muted-foreground",
}

/** A completed session whose agent marked its summary for attention. */
export const needsAttention = (o: SessionOverview | null | undefined) =>
  o?.state === "completed" && !!o.summary && o.summary_tone === "attention"

export function StateDot({
  state,
  attention = false,
  className,
}: {
  state: SessionState | undefined
  attention?: boolean
  className?: string
}) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        "inline-block size-2 shrink-0 rounded-full",
        attention ? "bg-warning" : state ? DOT[state] : "bg-border",
        className,
      )}
    />
  )
}

export function stateText(o: SessionOverview | null | undefined) {
  if (!o) return "–"
  return o.state === "completed" && o.summary ? o.summary : STATE_LABEL[o.state]
}

export function StateBadge({ overview }: { overview: SessionOverview | null | undefined }) {
  const state = overview?.state
  return (
    <span
      className={cn(
        "inline-flex h-5 shrink-0 items-center gap-1.5 rounded-full border border-border px-2 text-xs font-medium whitespace-nowrap",
        needsAttention(overview) ? "text-warning" : state ? TEXT[state] : "text-muted-foreground",
      )}
      title={overview?.summary || undefined}
    >
      <StateDot state={state} attention={needsAttention(overview)} />
      {state ? STATE_LABEL[state] : "–"}
    </span>
  )
}

/** Keep authored text readable without making long summaries dominate the page. */
export function SessionSummary({
  text,
  tone,
}: {
  text: string
  tone?: "neutral" | "attention" | null
}) {
  const color = tone === "attention" ? "text-warning" : "text-muted-foreground"
  if (text.length <= 180) return <p className={cn("break-words text-sm", color)}>{text}</p>
  return (
    <details className="group">
      <summary className="cursor-pointer list-none [&::-webkit-details-marker]:hidden">
        <span className={cn("line-clamp-2 break-words text-sm group-open:line-clamp-none", color)}>
          {text}
        </span>
        <span className="mt-1 block text-xs text-muted-foreground">
          <span className="group-open:hidden">Show full summary</span>
          <span className="hidden group-open:inline">Collapse summary</span>
        </span>
      </summary>
    </details>
  )
}

export function LabelChips({
  labels,
  className,
}: {
  labels: Record<string, string>
  className?: string
}) {
  const entries = Object.entries(labels)
  if (!entries.length) return null
  return (
    <span className={cn("flex flex-wrap gap-1", className)}>
      {entries.map(([k, v]) => (
        <span
          key={k}
          className="rounded-md border border-border px-1.5 py-px font-mono text-[11px] text-muted-foreground"
        >
          {k}={v}
        </span>
      ))}
    </span>
  )
}

export function Kbd({ children }: { children: ReactNode }) {
  return (
    <kbd className="rounded border border-border bg-background px-1 font-sans text-[10px] text-muted-foreground">
      {children}
    </kbd>
  )
}

// Shared with the parts in src/parts, which apps import.
export { EmptyState, ErrorState } from "../../parts/states"

/* ---------- shell state shared by the sidebar and each page's top bar ---------- */

export type Shell = {
  sidebarHidden: boolean
  setSidebarHidden: (hidden: boolean) => void
  mobileOpen: boolean
  setMobileOpen: (open: boolean) => void
  focusSearch: () => void
  sidebarToggleRef?: RefObject<HTMLButtonElement | null>
  desktopSidebarToggleRef?: RefObject<HTMLButtonElement | null>
  roleLabel?: string
  pageLayout?: boolean
}
export const ShellContext = createContext<Shell | null>(null)
export function useShell() {
  const shell = useContext(ShellContext)
  if (!shell) throw new Error("useShell must be used inside the dashboard layout.")
  return shell
}

/** The bar at the top of each page: sidebar toggles, a title, and the page's actions. */
export function TopBar({ children, actions }: { children?: ReactNode; actions?: ReactNode }) {
  const shell = useContext(ShellContext)
  return (
    <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-3 sm:px-4">
      {shell && (
        <Button
          variant="ghost"
          size="icon-sm"
          className="md:hidden"
          ref={shell.sidebarToggleRef}
          aria-expanded={shell.mobileOpen}
          aria-label="Open sidebar"
          onClick={() => shell.setMobileOpen(true)}
        >
          <Menu />
        </Button>
      )}
      {shell?.sidebarHidden && (
        <Button
          variant="ghost"
          size="icon-sm"
          className="hidden md:inline-flex"
          ref={shell.desktopSidebarToggleRef}
          aria-label="Show sidebar"
          onClick={() => shell.setSidebarHidden(false)}
        >
          <PanelLeft />
        </Button>
      )}
      <h1 className="min-w-0 flex-1 truncate text-sm font-medium">{children}</h1>
      {shell?.roleLabel && (
        <span className="sr-only sm:not-sr-only sm:text-xs sm:text-muted-foreground">
          {shell.roleLabel}
        </span>
      )}
      {actions}
    </header>
  )
}

/**
 * A scrolling page body with a centered column. Back and Forward return it to where it
 * was being read, as a browser does for a whole page; following a link starts at the top.
 */
export function PageBody({
  children,
  width = "max-w-5xl",
}: {
  children: ReactNode
  width?: string
}) {
  const scroller = useRef<HTMLDivElement>(null)
  const content = useRef<HTMLDivElement>(null)
  const entry = useRouterState({ select: (s) => s.location.state.__TSR_key ?? s.location.href })
  const key = `page:${entry}`
  const restoring = useRef(false)
  useLayoutEffect(() => {
    const saved = readReadingPosition(key)
    if (!saved || !scroller.current || !content.current) return
    restoring.current = true
    return restoreScrollPosition(scroller.current, content.current, saved.top, () => {
      restoring.current = false
    })
  }, [key])
  return (
    <div
      ref={scroller}
      className="relative min-h-0 flex-1 overflow-y-auto"
      onScroll={(event) => {
        if (!restoring.current)
          writeReadingPosition(key, readingPositionFromScroll(event.currentTarget, "page"))
      }}
    >
      <div ref={content} className={cn("mx-auto w-full px-4 py-5 sm:px-6", width)}>
        {children}
      </div>
    </div>
  )
}

/** Shared dismissal/focus owner for compact action disclosures. */
export function ActionsMenu({
  open,
  onOpenChange,
  children,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  children: ReactNode
}) {
  return (
    <Popover.Root open={open} onOpenChange={onOpenChange}>
      <Popover.Trigger render={<Button variant="ghost" size="icon-sm" aria-label="More actions" />}>
        <Ellipsis />
      </Popover.Trigger>
      <Popover.Portal>
        <Popover.Positioner align="end" sideOffset={4} className="z-50">
          <Popover.Popup
            initialFocus={false}
            className="w-60 max-w-[calc(100vw-2rem)] rounded-lg border border-border bg-popover p-1 text-sm shadow-lg"
          >
            {children}
          </Popover.Popup>
        </Popover.Positioner>
      </Popover.Portal>
    </Popover.Root>
  )
}
