import { useQuery, useQueryClient } from "@tanstack/react-query"
import { CheckCircle2, Copy, FlaskConical, LoaderCircle, Plus, Save, Trash2 } from "lucide-react"
import { type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from "react"
import { ExpectedBehaviorEditor } from "@/components/dashboard/evaluation-promotion"
import {
  ScenarioAuthoring,
  type ScenarioAuthoringState,
} from "@/components/dashboard/scenario-authoring"
import { StructuredJudgeEditor } from "@/components/dashboard/structured-judge-editor"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import { Textarea } from "@/components/ui/textarea"
import {
  ApiClientError,
  type EvalAuthoredSuite,
  type EvalAuthoredSuiteDraft,
  type EvalAuthoredSuitePreview,
  type EvalAuthoredSuiteRunLaunched,
  type EvalAuthoredSuiteRunPreview,
  type EvalScenario,
  fetchEvalAuthoredSuite,
  fetchEvalAuthoredSuites,
  fetchEvalScenario,
  fetchEvalTargets,
  launchEvalAuthoredSuiteRun,
  previewEvalAuthoredSuite,
  previewEvalAuthoredSuiteRun,
  saveEvalAuthoredSuite,
} from "@/lib/api"
import { dashboardConfig } from "@/lib/config"
import {
  newMemoryUseJudgeAssertion,
  newStructuredJudgeAssertion,
  structuredAssertionFromReviewedSuite,
} from "@/lib/eval-judge-authoring"
import {
  authoredSuiteCostBudgetContract,
  authoredSuiteRunPreviewIdentity,
  blankEvalScenarioDraft,
  duplicateEvalSuiteCase,
  EVAL_SUITE_MAX_CASES,
  evalSuiteDraftFromDocument,
  newEvalSuiteDraft,
  newSimpleEvalCase,
  validateEvalSuiteDraft,
} from "@/lib/eval-suite-authoring"
import {
  authoredSuiteEvalLaunchRequestIdentity,
  EVAL_TARGET_QUERY_KEY,
  EvalLaunchIdempotencyRegistry,
  evalErrorMessage,
  evalLaunchFailureIsDefinitive,
  evalTargetCatalogMayBeStale,
  shortEvalIdentity,
} from "@/lib/evals-dashboard"
import { createPromotionAssertion, type PromotionAssertion } from "@/lib/evaluation-promotion"
import type {
  EvalCaseDraftV2,
  EvalScenarioDraftV2,
  EvalSuiteRunExposureV1,
  StructuredModelJudgeAssertionDraftV1,
} from "@/lib/generated/server-api"

const FIELD_LABEL = "mb-1 block text-xs font-medium text-muted-foreground"

type EvalSuiteAuthoringProps = {
  targetKey: string
  initialRevision?: string
  label?: string
  disabled: boolean
  onLaunched: (runIds: string[]) => Promise<void>
}

/** Keep each specialist's draft when switching the surrounding catalog filter. */
export function EvalSuiteAuthoringAction(props: EvalSuiteAuthoringProps) {
  const scope = JSON.stringify([props.targetKey, props.initialRevision ?? null])
  const [owners, setOwners] = useState([
    { scope, targetKey: props.targetKey, initialRevision: props.initialRevision },
  ])
  if (props.initialRevision) {
    return <EvalSuiteAuthoringEditor {...props} key={scope} active />
  }
  if (!owners.some((owner) => owner.scope === scope)) {
    setOwners([
      ...owners,
      { scope, targetKey: props.targetKey, initialRevision: props.initialRevision },
    ])
  }
  return owners.map((owner) => (
    <EvalSuiteAuthoringEditor
      {...props}
      key={owner.scope}
      targetKey={owner.targetKey}
      initialRevision={owner.initialRevision}
      active={owner.scope === scope}
    />
  ))
}

function EvalSuiteAuthoringEditor({
  targetKey,
  disabled,
  onLaunched,
  initialRevision,
  label = "New suite",
  active,
}: EvalSuiteAuthoringProps & { active: boolean }) {
  const initialized = useRef(!initialRevision)
  const queryClient = useQueryClient()
  const [open, setOpen] = useState(false)
  const [draft, setDraft] = useState<EvalAuthoredSuiteDraft>(() => newEvalSuiteDraft(targetKey))
  const caseRowSequenceRef = useRef(0)
  const allocateCaseRowKey = () => {
    caseRowSequenceRef.current += 1
    return `case-row-${caseRowSequenceRef.current}`
  }
  const allocateCaseRowKeys = (count: number) => Array.from({ length: count }, allocateCaseRowKey)
  const [caseRowKeys, setCaseRowKeys] = useState(() => allocateCaseRowKeys(draft.cases.length))
  const [activeCaseKey, setActiveCaseKey] = useState(caseRowKeys[0] ?? "")
  const [selectedCaseKeys, setSelectedCaseKeys] = useState<Set<string>>(() => new Set(caseRowKeys))
  const [scenarioDrafts, setScenarioDrafts] = useState<Record<string, EvalScenarioDraftV2>>({})
  const [savedScenarios, setSavedScenarios] = useState<Record<string, EvalScenario>>({})
  const [scenarioAuthoringState, setScenarioAuthoringState] = useState<
    (ScenarioAuthoringState & { caseKey: string }) | null
  >(null)
  const [scenarioEditorEpoch, setScenarioEditorEpoch] = useState(0)
  const [suitePreview, setSuitePreview] = useState<EvalAuthoredSuitePreview | null>(null)
  const [suitePreviewIdentity, setSuitePreviewIdentity] = useState<string | null>(null)
  const [savedRevision, setSavedRevision] = useState<string | null>(null)
  const [runPreview, setRunPreview] = useState<EvalAuthoredSuiteRunPreview | null>(null)
  const [runPreviewIdentity, setRunPreviewIdentity] = useState<string | null>(null)
  const [launchMaximumCost, setLaunchMaximumCost] = useState("")
  const [launchCostCurrency, setLaunchCostCurrency] = useState("USD")
  const [pending, setPending] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const controllerRef = useRef<AbortController | null>(null)
  const launchRegistryRef = useRef<EvalLaunchIdempotencyRegistry | null>(null)
  const authoredSuites = useQuery({
    queryKey: ["evals", "authored-suites", targetKey],
    queryFn: ({ signal }) => fetchEvalAuthoredSuites({ target_key: targetKey, limit: 50 }, signal),
    enabled: open && active,
  })
  const targets = useQuery({
    queryKey: EVAL_TARGET_QUERY_KEY,
    queryFn: ({ signal }) => fetchEvalTargets(signal),
    enabled: open && active,
  })
  const target = targets.data?.items.find((item) => item.target_key === targetKey)
  const independentJudgeProfile = target?.judge_profiles?.find(
    (profile) =>
      target.judge_profile_routes?.find(
        (route) =>
          route.judge_profile_key === profile.key &&
          route.judge_profile_revision === profile.revision,
      )?.candidate_route_relation === "independent_model",
  )
  const sameModelJudgeProfile = target?.judge_profiles?.find(
    (profile) =>
      target.judge_profile_routes?.find(
        (route) =>
          route.judge_profile_key === profile.key &&
          route.judge_profile_revision === profile.revision,
      )?.candidate_route_relation === "same_model" &&
      profile.same_model_use === "allowed_and_labeled",
  )
  const defaultJudgeProfile = independentJudgeProfile ?? sameModelJudgeProfile
  const defaultJudgeIsSameModel =
    independentJudgeProfile === undefined && sameModelJudgeProfile !== undefined
  const memoryJudgeProfiles = target?.judge_profiles?.filter(
    (profile) =>
      profile.allowed_evidence.includes("final_output") &&
      profile.allowed_evidence.includes("public_reference"),
  )
  const independentMemoryJudgeProfile = memoryJudgeProfiles?.find(
    (profile) =>
      target?.judge_profile_routes?.find(
        (route) =>
          route.judge_profile_key === profile.key &&
          route.judge_profile_revision === profile.revision,
      )?.candidate_route_relation === "independent_model",
  )
  const sameModelMemoryJudgeProfile = memoryJudgeProfiles?.find(
    (profile) =>
      target?.judge_profile_routes?.find(
        (route) =>
          route.judge_profile_key === profile.key &&
          route.judge_profile_revision === profile.revision,
      )?.candidate_route_relation === "same_model" &&
      profile.same_model_use === "allowed_and_labeled",
  )
  const defaultMemoryJudgeProfile = independentMemoryJudgeProfile ?? sameModelMemoryJudgeProfile
  const activeCaseIndex = Math.max(0, caseRowKeys.indexOf(activeCaseKey))
  const activeCase = draft.cases[activeCaseIndex] ?? draft.cases[0]
  const activeCaseRowKey = caseRowKeys[activeCaseIndex]
  const activeScenarioAuthoringState =
    scenarioAuthoringState?.caseKey === activeCaseRowKey ? scenarioAuthoringState : null
  const activeScenarioDirty = activeScenarioAuthoringState?.dirty === true
  const activeScenarioPending = activeScenarioAuthoringState?.pending === true
  const unsavedScenarioReference = Object.keys(scenarioDrafts).length > 0
  const activeScenarioRevision =
    activeCase && isScenarioCase(activeCase) ? activeCase.stimulus.scenario_revision : null
  const loadedScenario = useQuery({
    queryKey: ["evals", "scenario", activeScenarioRevision],
    queryFn: ({ signal }) => fetchEvalScenario(activeScenarioRevision ?? "", signal),
    enabled:
      open &&
      active &&
      activeScenarioRevision !== null &&
      (activeCaseRowKey === undefined || savedScenarios[activeCaseRowKey] === undefined),
  })
  const currentIdentity = useMemo(() => JSON.stringify(draft), [draft])
  const previewCurrent =
    suitePreview !== null &&
    suitePreviewIdentity === currentIdentity &&
    !unsavedScenarioReference &&
    !activeScenarioDirty
  const activeStructuredJudges =
    activeCase?.assertions.filter(
      (assertion): assertion is StructuredModelJudgeAssertionDraftV1 =>
        assertion.kind === "structured_model_judge",
    ) ?? []
  const activeDeterministicAssertions =
    activeCase?.assertions.filter(
      (assertion): assertion is PromotionAssertion => assertion.kind !== "structured_model_judge",
    ) ?? []
  const hasMemoryStructuralAssertion = activeDeterministicAssertions.some(
    (assertion) => assertion.kind === "memory_attribution",
  )
  const memorySemanticJudge = activeStructuredJudges.find(
    (assertion) => assertion.rubric.id === "memory-use",
  )
  const hasMemorySemanticJudge = memorySemanticJudge !== undefined
  const memorySemanticJudgeNeedsReference =
    memorySemanticJudge?.reference?.kind === "public_reference" &&
    memorySemanticJudge.reference.expected_answer == null &&
    (memorySemanticJudge.reference.expected_facts ?? []).every((fact) => fact.trim().length === 0)
  const reviewedActiveCase =
    suitePreview && previewCurrent
      ? suitePreview.suite.cases.find((item) => item.id === activeCase?.id)
      : undefined
  const defaultCalibrationMessages =
    activeCase && "input" in activeCase.stimulus ? (activeCase.stimulus.input.messages ?? []) : []
  const defaultCalibrationTask =
    defaultCalibrationMessages.length > 0
      ? defaultCalibrationMessages.map((message) => message.text).join("\n")
      : (activeCase?.name ?? "Evaluate the saved scenario.")
  const launchCostBudget = useMemo(
    () => authoredSuiteCostBudgetContract(launchMaximumCost, launchCostCurrency, target),
    [launchCostCurrency, launchMaximumCost, target],
  )
  const launchCostBudgetInvalid = launchCostBudget === null
  const launchSelection = useMemo(() => {
    const selected = draft.cases
      .filter((_, index) => {
        const caseKey = caseRowKeys[index]
        return caseKey !== undefined && selectedCaseKeys.has(caseKey)
      })
      .map((item) => item.id)
      .sort()
    const selection = selected.length === draft.cases.length ? {} : { case_ids: selected }
    return launchCostBudget === undefined
      ? selection
      : { ...selection, cost_budget: launchCostBudget }
  }, [caseRowKeys, draft.cases, launchCostBudget, selectedCaseKeys])
  const currentRunPreviewIdentity = useMemo(
    () =>
      authoredSuiteRunPreviewIdentity(
        savedRevision,
        suitePreview?.suite.revision ?? null,
        launchSelection,
      ),
    [savedRevision, suitePreview?.suite.revision, launchSelection],
  )
  const runPreviewCurrent =
    runPreview !== null &&
    runPreviewIdentity === currentRunPreviewIdentity &&
    previewCurrent &&
    savedRevision !== null &&
    savedRevision === suitePreview?.suite.revision
  const authoringPending = pending !== null || activeScenarioPending
  const authoringLocked = disabled || !active || authoringPending
  const scenarioHasUnsavedChanges = unsavedScenarioReference || activeScenarioDirty
  const scenarioTransitionLocked = authoringPending || scenarioHasUnsavedChanges

  useEffect(() => () => controllerRef.current?.abort(), [])
  useEffect(() => {
    if (!active) {
      setOpen(false)
      controllerRef.current?.abort()
    }
  }, [active])

  useEffect(() => {
    const currencies = target?.cost_budget_currencies ?? []
    if (currencies.length > 0 && !currencies.includes(launchCostCurrency)) {
      setLaunchCostCurrency(currencies[0] ?? "USD")
    }
  }, [launchCostCurrency, target?.cost_budget_currencies])

  const editDraft = (edit: (next: EvalAuthoredSuiteDraft) => void) => {
    initialized.current = true
    setDraft((current) => {
      const next = structuredClone(current)
      edit(next)
      return next
    })
  }

  const run = async (name: string, action: (signal: AbortSignal) => Promise<void>) => {
    controllerRef.current?.abort()
    const controller = new AbortController()
    controllerRef.current = controller
    setPending(name)
    setError(null)
    setNotice(null)
    try {
      await action(controller.signal)
    } catch (actionError) {
      if (!controller.signal.aborted) {
        setError(evalErrorMessage(actionError, "The authored evaluation operation failed."))
      }
    } finally {
      if (controllerRef.current === controller) {
        controllerRef.current = null
        setPending(null)
      }
    }
  }

  const resetToNewSuite = () => {
    if (authoringLocked || scenarioHasUnsavedChanges) return
    initialized.current = true
    const next = newEvalSuiteDraft(targetKey)
    const nextCaseKeys = allocateCaseRowKeys(next.cases.length)
    setDraft(next)
    setCaseRowKeys(nextCaseKeys)
    setActiveCaseKey(nextCaseKeys[0] ?? "")
    setSelectedCaseKeys(new Set(nextCaseKeys))
    setScenarioDrafts({})
    setSavedScenarios({})
    setScenarioAuthoringState(null)
    setScenarioEditorEpoch((current) => current + 1)
    setSuitePreview(null)
    setSuitePreviewIdentity(null)
    setSavedRevision(null)
    setRunPreview(null)
    setRunPreviewIdentity(null)
    setError(null)
    setNotice(null)
  }

  const loadSuite = (revision: string) => {
    if (scenarioTransitionLocked) return
    void run("load", async (signal) => {
      const document = await fetchEvalAuthoredSuite(revision, signal)
      if (signal.aborted) return
      loadDocument(document)
      setNotice(`Loaded immutable suite ${shortEvalIdentity(document.revision)}.`)
    })
  }

  const loadDocument = (document: EvalAuthoredSuite) => {
    initialized.current = true
    const next = evalSuiteDraftFromDocument(document)
    const nextCaseKeys = allocateCaseRowKeys(next.cases.length)
    setDraft(next)
    setCaseRowKeys(nextCaseKeys)
    setActiveCaseKey(nextCaseKeys[0] ?? "")
    setSelectedCaseKeys(new Set(nextCaseKeys))
    setScenarioDrafts({})
    setSavedScenarios({})
    setScenarioAuthoringState(null)
    setScenarioEditorEpoch((current) => current + 1)
    setSuitePreview(null)
    setSuitePreviewIdentity(null)
    setSavedRevision(document.revision)
    setRunPreview(null)
    setRunPreviewIdentity(null)
  }

  const addCase = () => {
    if (
      authoringLocked ||
      scenarioHasUnsavedChanges ||
      draft.cases.length >= EVAL_SUITE_MAX_CASES
    ) {
      return
    }
    const nextCase = newSimpleEvalCase(draft.cases)
    const nextCaseKey = allocateCaseRowKey()
    editDraft((next) => next.cases.push(nextCase))
    setCaseRowKeys((current) => [...current, nextCaseKey])
    setActiveCaseKey(nextCaseKey)
    setSelectedCaseKeys((current) => new Set(current).add(nextCaseKey))
  }

  const duplicateActiveCase = () => {
    if (
      authoringLocked ||
      scenarioHasUnsavedChanges ||
      draft.cases.length >= EVAL_SUITE_MAX_CASES
    ) {
      return
    }
    if (!activeCase || activeCaseRowKey === undefined) return
    const duplicate = duplicateEvalSuiteCase(draft.cases, activeCaseIndex)
    const duplicateCaseKey = allocateCaseRowKey()
    editDraft((next) => next.cases.push(duplicate))
    setCaseRowKeys((current) => [...current, duplicateCaseKey])
    setActiveCaseKey(duplicateCaseKey)
    setSelectedCaseKeys((current) => new Set(current).add(duplicateCaseKey))
  }

  const removeActiveCase = () => {
    if (
      authoringLocked ||
      scenarioHasUnsavedChanges ||
      !activeCase ||
      activeCaseRowKey === undefined ||
      draft.cases.length === 1
    ) {
      return
    }
    const remainingCaseKeys = caseRowKeys.filter((_, index) => index !== activeCaseIndex)
    editDraft((next) => {
      next.cases.splice(activeCaseIndex, 1)
    })
    setCaseRowKeys(remainingCaseKeys)
    setActiveCaseKey(remainingCaseKeys[0] ?? "")
    setSelectedCaseKeys((current) => {
      const next = new Set(current)
      next.delete(activeCaseRowKey)
      return next
    })
    setScenarioDrafts((current) => withoutKey(current, activeCaseRowKey))
    setSavedScenarios((current) => withoutKey(current, activeCaseRowKey))
  }

  const switchStimulus = (kind: "simple_input" | "scenario") => {
    if (
      authoringLocked ||
      scenarioHasUnsavedChanges ||
      !activeCase ||
      activeCaseRowKey === undefined
    ) {
      return
    }
    setScenarioAuthoringState(null)
    if (kind === "simple_input") {
      const simple = newSimpleEvalCase([], activeCase.id)
      editDraft((next) => {
        const current = next.cases[activeCaseIndex]
        if (current) current.stimulus = simple.stimulus
      })
      setScenarioDrafts((current) => withoutKey(current, activeCaseRowKey))
      setSavedScenarios((current) => withoutKey(current, activeCaseRowKey))
      return
    }
    setScenarioDrafts((current) => ({
      ...current,
      [activeCaseRowKey]: blankEvalScenarioDraft(targetKey, activeCase),
    }))
  }

  const previewSuite = () => {
    if (authoringLocked) return
    if (unsavedScenarioReference) {
      setError("Save every new scenario before checking the suite.")
      return
    }
    if (activeScenarioDirty) {
      setError("Save the visible scenario edits before checking the suite.")
      return
    }
    const validation = validateEvalSuiteDraft(draft)
    if (!validation.ok) {
      setError(validation.error)
      return
    }
    const identity = currentIdentity
    void run("preview", async (signal) => {
      const next = await previewEvalAuthoredSuite({ draft: validation.draft }, signal)
      if (signal.aborted) return
      setSuitePreview(next)
      setSuitePreviewIdentity(identity)
    })
  }

  const saveSuite = () => {
    if (authoringLocked || !previewCurrent || !suitePreview?.ready) return
    void run("save", async (signal) => {
      const saved = await saveEvalAuthoredSuite(
        {
          expected_suite_revision: suitePreview.suite.revision,
          suite: suitePreview.suite,
        },
        signal,
      )
      if (signal.aborted) return
      const normalized = evalSuiteDraftFromDocument(saved.suite)
      const caseKeyById = new Map(
        draft.cases.flatMap((evalCase, index) => {
          const caseKey = caseRowKeys[index]
          return caseKey === undefined ? [] : ([[evalCase.id, caseKey]] as const)
        }),
      )
      const normalizedCaseKeys = normalized.cases.map(
        (evalCase) => caseKeyById.get(evalCase.id) ?? allocateCaseRowKey(),
      )
      setDraft(normalized)
      setCaseRowKeys(normalizedCaseKeys)
      setSuitePreview({
        suite: saved.suite,
        full_selection: saved.full_selection,
        ready: true,
        diagnostics: [],
      })
      setSuitePreviewIdentity(JSON.stringify(normalized))
      setSavedRevision(saved.suite.revision)
      setSelectedCaseKeys((current) => {
        const retainedKeys = new Set(normalizedCaseKeys)
        return new Set([...current].filter((caseKey) => retainedKeys.has(caseKey)))
      })
      setNotice(`Saved immutable suite ${shortEvalIdentity(saved.suite.revision)}.`)
      await queryClient.invalidateQueries({ queryKey: ["evals"] })
    })
  }

  const previewRun = () => {
    if (authoringLocked) return
    if (launchCostBudgetInvalid) {
      setError("Enter a positive cost ceiling in one currency published by this target.")
      return
    }
    if (!previewCurrent || savedRevision !== suitePreview?.suite.revision) {
      setError("Check and save the current suite revision before launch readiness.")
      return
    }
    if (selectedCaseKeys.size === 0) {
      setError("Select at least one case to run.")
      return
    }
    const identity = currentRunPreviewIdentity
    void run("run-preview", async (signal) => {
      const next = await previewEvalAuthoredSuiteRun(savedRevision, launchSelection, signal)
      if (signal.aborted) return
      setRunPreview(next)
      setRunPreviewIdentity(identity)
    })
  }

  const launch = () => {
    if (
      authoringLocked ||
      !runPreviewCurrent ||
      !runPreview?.ready ||
      !runPreview.exposure ||
      launchCostBudgetInvalid ||
      savedRevision === null ||
      savedRevision !== suitePreview?.suite.revision
    ) {
      return
    }
    const reviewedExposure = runPreview.exposure
    const expectedExecutionProfiles = runPreview.launches.flatMap((item) =>
      item.execution_profile_revision
        ? [
            {
              case_ids: item.case_ids,
              execution_profile_revision: item.execution_profile_revision,
            },
          ]
        : [],
    )
    if (expectedExecutionProfiles.length !== runPreview.launches.length) return
    const requestIdentity = authoredSuiteEvalLaunchRequestIdentity(
      savedRevision,
      runPreview.selection.revision,
      reviewedExposure.revision,
      expectedExecutionProfiles,
    )
    void run("launch", async (signal) => {
      const registry =
        launchRegistryRef.current ??
        new EvalLaunchIdempotencyRegistry(window.sessionStorage, dashboardConfig.apiBaseUrl)
      launchRegistryRef.current = registry
      const idempotencyKey = registry.keyFor(requestIdentity)
      let launched: EvalAuthoredSuiteRunLaunched
      try {
        launched = await launchEvalAuthoredSuiteRun(
          savedRevision,
          {
            ...launchSelection,
            expected_execution_profiles: expectedExecutionProfiles,
            expected_exposure_revision: reviewedExposure.revision,
          },
          idempotencyKey,
          signal,
        )
      } catch (launchError) {
        if (evalTargetCatalogMayBeStale(launchError)) {
          await queryClient.invalidateQueries({ queryKey: EVAL_TARGET_QUERY_KEY })
        }
        if (
          launchError instanceof ApiClientError &&
          evalLaunchFailureIsDefinitive(launchError.status)
        ) {
          registry.resolve(requestIdentity)
        }
        throw launchError
      }
      if (signal.aborted) return
      const runIds = launched.runs.map((item) => item.run.spec.run_id)
      for (const item of launched.runs) {
        queryClient.setQueryData(["evals", "run", item.run.spec.run_id], item.run)
      }
      await queryClient.invalidateQueries({ queryKey: ["evals"] })
      if (signal.aborted) return
      registry.resolve(requestIdentity)
      setNotice(
        `Started ${runIds.length} durable eval ${runIds.length === 1 ? "run" : "runs"} for ${launched.selection.cases.length} selected ${launched.selection.cases.length === 1 ? "case" : "cases"}.`,
      )
      await onLaunched(runIds)
    })
  }

  const retainSavedScenario = (caseKey: string, scenario: EvalScenario) => {
    const caseIndex = caseRowKeys.indexOf(caseKey)
    const caseId = caseIndex < 0 ? null : draft.cases[caseIndex]?.id
    if (caseIndex < 0 || caseId === null || caseId === undefined) return
    setSavedScenarios((current) => ({
      ...current,
      [caseKey]: scenario,
    }))
    setScenarioDrafts((current) => withoutKey(current, caseKey))
    editDraft((next) => {
      const current = next.cases[caseIndex]
      if (current) {
        current.stimulus = {
          kind: "scenario",
          scenario_id: scenario.id,
          scenario_revision: scenario.revision,
        }
      }
    })
    setNotice(`Saved scenario ${shortEvalIdentity(scenario.revision)} for ${caseId}.`)
  }

  const selectCaseForLaunch = (caseKey: string, selected: boolean) => {
    if (authoringLocked) return
    setSelectedCaseKeys((current) => {
      const next = new Set(current)
      if (selected) next.add(caseKey)
      else next.delete(caseKey)
      return next
    })
  }

  const retainScenarioAuthoringState = useCallback(
    (caseKey: string, state: ScenarioAuthoringState) => {
      setScenarioAuthoringState((current) => {
        if (!state.dirty && !state.pending) {
          return current?.caseKey === caseKey ? null : current
        }
        if (
          current?.caseKey === caseKey &&
          current.dirty === state.dirty &&
          current.pending === state.pending
        ) {
          return current
        }
        return { caseKey, ...state }
      })
    },
    [],
  )
  const reportActiveScenarioAuthoringState = useCallback(
    (state: ScenarioAuthoringState) => {
      if (activeCaseRowKey !== undefined) {
        retainScenarioAuthoringState(activeCaseRowKey, state)
      }
    },
    [activeCaseRowKey, retainScenarioAuthoringState],
  )

  const scenarioForActiveCase = activeCaseRowKey
    ? (savedScenarios[activeCaseRowKey] ?? loadedScenario.data)
    : undefined
  const scenarioDraftForActiveCase = activeCaseRowKey ? scenarioDrafts[activeCaseRowKey] : undefined

  const discardActiveScenarioEdits = () => {
    if (
      authoringPending ||
      !activeCase ||
      activeCaseRowKey === undefined ||
      !scenarioHasUnsavedChanges
    ) {
      return
    }
    if (scenarioDraftForActiveCase !== undefined) {
      setScenarioDrafts((current) => withoutKey(current, activeCaseRowKey))
      setNotice("Discarded the unsaved scenario draft and restored the simple input.")
    } else if (isScenarioCase(activeCase)) {
      setScenarioEditorEpoch((current) => current + 1)
      setNotice("Discarded the unsaved scenario edits and restored the saved revision.")
    } else {
      return
    }
    setScenarioAuthoringState(null)
    setError(null)
  }

  return (
    <>
      {active && (
        <Button
          type="button"
          data-testid="new-evaluation"
          disabled={disabled}
          onClick={() => {
            setOpen(true)
            if (initialRevision && !initialized.current) loadSuite(initialRevision)
          }}
        >
          <Plus /> {label}
        </Button>
      )}
      <Sheet
        open={open && active}
        onOpenChange={(next) => {
          if (!next && scenarioTransitionLocked) return
          setOpen(next)
          if (!next) {
            controllerRef.current?.abort()
            setScenarioAuthoringState(null)
          }
        }}
      >
        <SheetContent
          className="@container/eval-sheet overflow-hidden data-[side=right]:w-[min(96vw,88rem)] data-[side=right]:sm:max-w-none"
          data-testid="eval-suite-authoring-sheet"
        >
          <SheetHeader>
            <SheetTitle>{initialRevision ? "Edit and run suite" : "New suite"}</SheetTitle>
            <SheetDescription className="break-words">
              Build a reusable deterministic suite, save its immutable revision, then run all cases
              or an explicit subset against {targetKey}.
            </SheetDescription>
          </SheetHeader>

          <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-4 overflow-y-auto px-4 pb-2 @min-[56rem]/eval-sheet:grid @min-[56rem]/eval-sheet:grid-cols-[18rem_minmax(0,1fr)] @min-[56rem]/eval-sheet:overflow-hidden">
            <aside className="max-h-64 min-h-0 min-w-0 shrink-0 space-y-3 overflow-y-auto rounded-lg border border-border p-3 @min-[56rem]/eval-sheet:max-h-none">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-sm font-medium">Suites</div>
                  <div className="text-xs text-muted-foreground">
                    Create new or reuse a revision
                  </div>
                </div>
                <Button
                  type="button"
                  size="xs"
                  variant="outline"
                  disabled={authoringLocked || scenarioHasUnsavedChanges}
                  onClick={resetToNewSuite}
                >
                  <Plus /> New
                </Button>
              </div>
              {authoredSuites.isLoading ? (
                <div className="text-xs text-muted-foreground">Loading saved suites...</div>
              ) : authoredSuites.isError ? (
                <div className="text-xs text-destructive">Saved suites could not be loaded.</div>
              ) : authoredSuites.data?.items.length ? (
                <div className="space-y-1.5" data-testid="authored-suite-catalog">
                  {authoredSuites.data.items.map((item) => (
                    <button
                      key={item.revision}
                      type="button"
                      className="w-full rounded-md border border-border px-2.5 py-2 text-left hover:bg-muted/50"
                      disabled={scenarioTransitionLocked}
                      onClick={() => loadSuite(item.revision)}
                    >
                      <div className="truncate text-sm font-medium">{item.name}</div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        {item.case_count} cases · {shortEvalIdentity(item.revision)}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="rounded-md border border-dashed border-border p-3 text-xs text-muted-foreground">
                  No authored suites yet.
                </div>
              )}

              <div className="border-t border-border pt-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-sm font-medium">Cases</div>
                    <div className="text-xs text-muted-foreground">Check cases to run</div>
                  </div>
                  <Button
                    type="button"
                    size="icon-xs"
                    variant="outline"
                    disabled={
                      authoringLocked ||
                      scenarioHasUnsavedChanges ||
                      draft.cases.length >= EVAL_SUITE_MAX_CASES
                    }
                    onClick={addCase}
                  >
                    <Plus />
                    <span className="sr-only">Add case</span>
                  </Button>
                </div>
                <div className="space-y-1.5" data-testid="authored-suite-cases">
                  {draft.cases.map((evalCase, index) => {
                    const caseKey = caseRowKeys[index]
                    if (caseKey === undefined) return null
                    return (
                      <div
                        key={caseKey}
                        data-state={activeCaseRowKey === caseKey ? "selected" : undefined}
                        className="flex items-center gap-2 rounded-md border border-border px-2 py-1.5 data-[state=selected]:border-primary/50 data-[state=selected]:bg-primary/5"
                      >
                        <input
                          type="checkbox"
                          checked={selectedCaseKeys.has(caseKey)}
                          disabled={authoringLocked}
                          aria-label={`Select ${evalCase.name} for launch`}
                          onChange={(event) => selectCaseForLaunch(caseKey, event.target.checked)}
                        />
                        <button
                          type="button"
                          className="min-w-0 flex-1 text-left"
                          disabled={scenarioTransitionLocked}
                          onClick={() => {
                            setScenarioAuthoringState(null)
                            setActiveCaseKey(caseKey)
                          }}
                        >
                          <div className="truncate text-sm font-medium">{evalCase.name}</div>
                          <div className="truncate font-mono text-[11px] text-muted-foreground">
                            {evalCase.id}
                          </div>
                        </button>
                        <Badge variant="outline">
                          {isScenarioCase(evalCase) || scenarioDrafts[caseKey]
                            ? "Scenario"
                            : "Simple"}
                        </Badge>
                      </div>
                    )
                  })}
                </div>
              </div>
            </aside>

            <div className="@container/eval-form min-w-0 shrink-0 pr-1 @min-[56rem]/eval-sheet:min-h-0 @min-[56rem]/eval-sheet:overflow-y-auto">
              <fieldset className="min-w-0 space-y-4" disabled={authoringLocked}>
                <Card size="sm">
                  <CardHeader className="grid-cols-[1fr_auto]">
                    <div>
                      <CardTitle>Suite</CardTitle>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Stable identity and bounded trial execution settings.
                      </p>
                    </div>
                    {savedRevision && (
                      <Badge variant="outline">Saved {shortEvalIdentity(savedRevision)}</Badge>
                    )}
                  </CardHeader>
                  <CardContent className="grid gap-3 @min-[28rem]/eval-form:grid-cols-2">
                    <Field label="Suite ID" id="authored-suite-id">
                      <Input
                        id="authored-suite-id"
                        data-testid="authored-suite-id"
                        value={draft.id}
                        onChange={(event) => editDraft((next) => (next.id = event.target.value))}
                      />
                    </Field>
                    <Field label="Suite name" id="authored-suite-name">
                      <Input
                        id="authored-suite-name"
                        data-testid="authored-suite-name"
                        value={draft.name}
                        onChange={(event) => editDraft((next) => (next.name = event.target.value))}
                      />
                    </Field>
                    <Field label="Description" id="authored-suite-description" wide>
                      <Textarea
                        id="authored-suite-description"
                        rows={2}
                        value={draft.description ?? ""}
                        onChange={(event) =>
                          editDraft((next) => (next.description = event.target.value || null))
                        }
                      />
                    </Field>
                    <Field label="Trials per case" id="authored-suite-trials">
                      <Input
                        id="authored-suite-trials"
                        type="number"
                        min={1}
                        max={target?.max_trials ?? 100}
                        value={draft.trial_request?.trials ?? 1}
                        onChange={(event) =>
                          editDraft((next) => {
                            const trials = Number(event.target.value)
                            const current = next.trial_request ?? {}
                            next.trial_request = {
                              ...current,
                              trials,
                              minimum_passed_trials: Math.min(
                                current.minimum_passed_trials ?? 1,
                                trials,
                              ),
                            }
                          })
                        }
                      />
                    </Field>
                    <Field label="Required passes" id="authored-suite-required-passes">
                      <Input
                        id="authored-suite-required-passes"
                        type="number"
                        min={1}
                        max={draft.trial_request?.trials ?? 1}
                        value={draft.trial_request?.minimum_passed_trials ?? 1}
                        onChange={(event) =>
                          editDraft((next) => {
                            next.trial_request = {
                              ...(next.trial_request ?? {}),
                              minimum_passed_trials: Number(event.target.value),
                            }
                          })
                        }
                      />
                    </Field>
                    <Field label="Maximum concurrency" id="authored-suite-concurrency">
                      <Input
                        id="authored-suite-concurrency"
                        type="number"
                        min={1}
                        max={target?.max_concurrency ?? 64}
                        value={draft.trial_request?.max_concurrency ?? 1}
                        onChange={(event) =>
                          editDraft((next) => {
                            next.trial_request = {
                              ...(next.trial_request ?? {}),
                              max_concurrency: Number(event.target.value),
                            }
                          })
                        }
                      />
                    </Field>
                    <Field label="Timeout per trial" id="authored-suite-timeout">
                      <Input
                        id="authored-suite-timeout"
                        type="number"
                        min={1}
                        max={3_600}
                        value={draft.trial_request?.timeout_seconds ?? 300}
                        onChange={(event) =>
                          editDraft((next) => {
                            next.trial_request = {
                              ...(next.trial_request ?? {}),
                              timeout_seconds: Number(event.target.value),
                            }
                          })
                        }
                      />
                    </Field>
                    <div className="self-end rounded-md border border-border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
                      Every admitted trial runs. Runtime, evaluator, or required-evidence errors
                      fail closed regardless of the pass threshold.
                    </div>
                  </CardContent>
                </Card>

                {activeCase && (
                  <>
                    <Card size="sm" data-testid="authored-case-editor">
                      <CardHeader className="grid-cols-[1fr_auto]">
                        <div>
                          <CardTitle>Case</CardTitle>
                          <p className="mt-1 text-xs text-muted-foreground">
                            Revise this portable case ID without mutating prior saved revisions.
                          </p>
                        </div>
                        <div className="flex gap-1.5">
                          <Button
                            type="button"
                            size="xs"
                            variant="outline"
                            disabled={
                              authoringLocked ||
                              scenarioHasUnsavedChanges ||
                              draft.cases.length >= EVAL_SUITE_MAX_CASES
                            }
                            onClick={duplicateActiveCase}
                          >
                            <Copy /> Duplicate
                          </Button>
                          <Button
                            type="button"
                            size="icon-xs"
                            variant="ghost"
                            aria-label={`Remove case ${activeCase.id}`}
                            disabled={
                              authoringLocked ||
                              scenarioHasUnsavedChanges ||
                              draft.cases.length === 1
                            }
                            onClick={removeActiveCase}
                          >
                            <Trash2 />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="grid gap-3 @min-[28rem]/eval-form:grid-cols-2">
                        <Field label="Case ID" id="authored-case-id">
                          <Input
                            id="authored-case-id"
                            data-testid="authored-case-id"
                            value={activeCase.id}
                            disabled={scenarioHasUnsavedChanges}
                            onChange={(event) => {
                              const nextId = event.target.value
                              editDraft((next) => {
                                const current = next.cases[activeCaseIndex]
                                if (current) current.id = nextId
                              })
                            }}
                          />
                        </Field>
                        <Field label="Case name" id="authored-case-name">
                          <Input
                            id="authored-case-name"
                            data-testid="authored-case-name"
                            value={activeCase.name}
                            onChange={(event) =>
                              editDraft((next) => {
                                const current = next.cases[activeCaseIndex]
                                if (current) current.name = event.target.value
                              })
                            }
                          />
                        </Field>
                        <Field label="Description" id="authored-case-description" wide>
                          <Textarea
                            id="authored-case-description"
                            rows={2}
                            value={activeCase.description ?? ""}
                            onChange={(event) =>
                              editDraft((next) => {
                                const current = next.cases[activeCaseIndex]
                                if (current) current.description = event.target.value || null
                              })
                            }
                          />
                        </Field>
                        <div className="@min-[28rem]/eval-form:col-span-2">
                          <span className={FIELD_LABEL}>Scenario type</span>
                          <div className="flex gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant={
                                !isScenarioCase(activeCase) && !scenarioDraftForActiveCase
                                  ? "default"
                                  : "outline"
                              }
                              disabled={scenarioHasUnsavedChanges}
                              onClick={() => switchStimulus("simple_input")}
                            >
                              Simple input
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant={
                                isScenarioCase(activeCase) || scenarioDraftForActiveCase
                                  ? "default"
                                  : "outline"
                              }
                              disabled={scenarioHasUnsavedChanges}
                              onClick={() => switchStimulus("scenario")}
                            >
                              Multi-stage scenario
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {!isScenarioCase(activeCase) && !scenarioDraftForActiveCase ? (
                      <SimpleInputEditor
                        evalCase={activeCase}
                        edit={(updated) =>
                          editDraft((next) => {
                            if (next.cases[activeCaseIndex]) {
                              next.cases[activeCaseIndex] = updated
                            }
                          })
                        }
                      />
                    ) : scenarioDraftForActiveCase ? (
                      <ScenarioAuthoring
                        key={`${activeCaseRowKey}:new-scenario:${scenarioEditorEpoch}`}
                        captured={scenarioDraftForActiveCase}
                        showLaunch={false}
                        showLaunchSettings={false}
                        onSaved={(scenario) =>
                          activeCaseRowKey && retainSavedScenario(activeCaseRowKey, scenario)
                        }
                        onAuthoringStateChange={reportActiveScenarioAuthoringState}
                      />
                    ) : scenarioForActiveCase ? (
                      <ScenarioAuthoring
                        key={`${activeCaseRowKey}:${scenarioForActiveCase.revision}:${scenarioEditorEpoch}`}
                        captured={scenarioForActiveCase}
                        saved
                        showLaunch={false}
                        showLaunchSettings={false}
                        onSaved={(scenario) =>
                          activeCaseRowKey && retainSavedScenario(activeCaseRowKey, scenario)
                        }
                        onAuthoringStateChange={reportActiveScenarioAuthoringState}
                      />
                    ) : loadedScenario.isError ? (
                      <div className="rounded-lg border border-destructive/30 p-4 text-sm text-destructive">
                        The exact saved scenario could not be loaded.
                      </div>
                    ) : (
                      <div className="rounded-lg border border-border p-4 text-sm text-muted-foreground">
                        Loading the exact scenario revision...
                      </div>
                    )}

                    <ExpectedBehaviorEditor
                      assertions={activeDeterministicAssertions}
                      evidence={undefined}
                      evidencePolicy={target?.execution_profile?.evidence_policy}
                      onChange={(assertions) =>
                        editDraft((next) => {
                          const current = next.cases[activeCaseIndex]
                          if (current)
                            current.assertions = [...assertions, ...activeStructuredJudges]
                        })
                      }
                    />

                    <div
                      className="space-y-3 rounded-lg border border-border bg-muted/20 p-3"
                      data-testid="eval-memory-authoring"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="max-w-3xl">
                          <div className="text-sm font-medium">Evaluate memory</div>
                          <div className="mt-1 text-xs text-muted-foreground">
                            Structural evidence proves admission and provider exposure. A trusted
                            reference lets the judge score correct use. Neither alone proves that
                            memory caused the result; use a paired memory experiment for that.
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            disabled={
                              authoringLocked ||
                              hasMemoryStructuralAssertion ||
                              activeCase.assertions.length >= 64
                            }
                            onClick={() =>
                              editDraft((next) => {
                                const current = next.cases[activeCaseIndex]
                                if (current) {
                                  current.assertions.push(
                                    createPromotionAssertion(
                                      "memory_attribution",
                                      current.assertions.filter(
                                        (item): item is PromotionAssertion =>
                                          item.kind !== "structured_model_judge",
                                      ),
                                    ),
                                  )
                                }
                              })
                            }
                          >
                            <Plus />
                            {hasMemoryStructuralAssertion
                              ? "Memory exposure added"
                              : "Require memory exposure"}
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            disabled={
                              authoringLocked ||
                              defaultMemoryJudgeProfile === undefined ||
                              hasMemorySemanticJudge ||
                              activeCase.assertions.length >= 64
                            }
                            onClick={() => {
                              const profile = defaultMemoryJudgeProfile
                              if (!profile) return
                              editDraft((next) => {
                                const current = next.cases[activeCaseIndex]
                                if (current) {
                                  current.assertions.push(
                                    newMemoryUseJudgeAssertion(
                                      profile,
                                      current.assertions.map((item) => item.id),
                                    ),
                                  )
                                }
                              })
                            }}
                          >
                            <Plus />
                            {hasMemorySemanticJudge
                              ? "Memory judge added"
                              : "Add reference-backed judge"}
                          </Button>
                        </div>
                      </div>
                      {defaultMemoryJudgeProfile === undefined && (
                        <div className="text-xs text-muted-foreground">
                          This target does not publish a trusted judge profile that permits final
                          output and public-reference evidence, so semantic memory scoring is
                          unavailable. Structural checks still work.
                        </div>
                      )}
                      {memorySemanticJudgeNeedsReference && (
                        <div className="text-xs text-amber-700 dark:text-amber-300">
                          Replace the blank expected fact in the memory-use judge with trusted
                          reference truth before checking or saving the suite.
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-dashed border-border p-3">
                      <div>
                        <div className="text-sm font-medium">AI judge</div>
                        <div className="text-xs text-muted-foreground">
                          Add a structured rubric when deterministic checks do not capture answer
                          quality.
                        </div>
                      </div>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={
                          authoringLocked ||
                          defaultJudgeProfile === undefined ||
                          activeCase.assertions.length >= 64
                        }
                        onClick={() => {
                          const profile = defaultJudgeProfile
                          if (!profile) return
                          editDraft((next) => {
                            const current = next.cases[activeCaseIndex]
                            if (current) {
                              current.assertions.push(
                                newStructuredJudgeAssertion(
                                  profile,
                                  current.assertions.map((item) => item.id),
                                ),
                              )
                            }
                          })
                        }}
                      >
                        <Plus />{" "}
                        {defaultJudgeIsSameModel ? "Add same-model AI judge" : "Add AI judge"}
                      </Button>
                      {(target?.judge_profiles?.length ?? 0) === 0 && (
                        <div className="w-full text-xs text-muted-foreground">
                          This target does not publish a trusted judge profile yet.
                        </div>
                      )}
                    </div>

                    {activeStructuredJudges.map((assertion) => {
                      const assertionIndex = activeCase.assertions.indexOf(assertion)
                      return (
                        <StructuredJudgeEditor
                          key={`${activeCaseRowKey}:${assertionIndex}`}
                          assertion={assertion}
                          target={target}
                          reviewedAssertion={structuredAssertionFromReviewedSuite(
                            assertion,
                            reviewedActiveCase?.assertions ?? [],
                          )}
                          defaultTask={defaultCalibrationTask}
                          disabled={authoringLocked}
                          onChange={(updated) =>
                            editDraft((next) => {
                              const current = next.cases[activeCaseIndex]
                              if (current) current.assertions[assertionIndex] = updated
                            })
                          }
                          onRemove={() =>
                            editDraft((next) => {
                              const current = next.cases[activeCaseIndex]
                              if (current) current.assertions.splice(assertionIndex, 1)
                            })
                          }
                        />
                      )
                    })}
                  </>
                )}
              </fieldset>

              <Card size="sm" className="mt-4" data-testid="authored-suite-cost-budget">
                <CardHeader>
                  <div>
                    <CardTitle>Candidate cost ceiling</CardTitle>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Optional per-trial runtime interruption budget. It narrows this launch and is
                      reviewed again before admission; it is not stored in the immutable suite.
                    </p>
                  </div>
                </CardHeader>
                <CardContent className="grid gap-3 @min-[28rem]/eval-form:grid-cols-2">
                  <Field label="Maximum cost per trial" id="authored-suite-maximum-cost">
                    <Input
                      id="authored-suite-maximum-cost"
                      data-testid="authored-suite-maximum-cost"
                      inputMode="decimal"
                      maxLength={64}
                      placeholder="No cost ceiling"
                      value={launchMaximumCost}
                      disabled={authoringLocked}
                      onChange={(event) => setLaunchMaximumCost(event.target.value)}
                    />
                  </Field>
                  <Field label="Cost currency" id="authored-suite-cost-currency">
                    <Input
                      id="authored-suite-cost-currency"
                      data-testid="authored-suite-cost-currency"
                      maxLength={16}
                      value={launchCostCurrency}
                      disabled={authoringLocked}
                      onChange={(event) => setLaunchCostCurrency(event.target.value.toUpperCase())}
                    />
                  </Field>
                  <p
                    className={`text-xs @min-[28rem]/eval-form:col-span-2 ${
                      launchCostBudgetInvalid ? "text-destructive" : "text-muted-foreground"
                    }`}
                  >
                    {target?.cost_budget_available === true
                      ? launchCostBudgetInvalid
                        ? "Use a positive canonical decimal and one of: " +
                          target.cost_budget_currencies.join(", ")
                        : `Published currencies: ${target.cost_budget_currencies.join(", ")}.`
                      : "This target has no compatible server-owned price book, so a monetary ceiling is unavailable."}
                  </p>
                </CardContent>
              </Card>

              {scenarioHasUnsavedChanges && (
                <div
                  className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-sm text-amber-700 dark:text-amber-300"
                  role="status"
                  data-testid="authored-suite-scenario-lock"
                >
                  <span>
                    Save or discard the visible scenario before leaving it or checking, saving, or
                    launching this suite.
                  </span>
                  <Button
                    type="button"
                    size="xs"
                    variant="outline"
                    disabled={authoringPending}
                    onClick={discardActiveScenarioEdits}
                  >
                    Discard scenario edits
                  </Button>
                </div>
              )}

              {suitePreview && previewCurrent && (
                <ReadinessSummary
                  title={suitePreview.ready ? "Suite is ready to save" : "Suite needs attention"}
                  ready={suitePreview.ready}
                  diagnostics={suitePreview.diagnostics ?? []}
                  identity={suitePreview.suite.revision}
                />
              )}
              {runPreview && runPreviewCurrent && (
                <>
                  <ReadinessSummary
                    title={
                      runPreview.ready
                        ? `${runPreview.launches.length} durable ${runPreview.launches.length === 1 ? "run" : "runs"} ready`
                        : "Launch needs attention"
                    }
                    ready={runPreview.ready}
                    diagnostics={runPreview.diagnostics ?? []}
                    identity={runPreview.selection.revision}
                  />
                  {runPreview.exposure && <RunExposureSummary exposure={runPreview.exposure} />}
                </>
              )}
              {error && (
                <div
                  className="mt-4 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
                  role="alert"
                  data-testid="authored-suite-error"
                >
                  {error}
                </div>
              )}
              {notice && (
                <div
                  className="mt-4 rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3 text-sm text-emerald-700 dark:text-emerald-300"
                  role="status"
                >
                  {notice}
                </div>
              )}
            </div>
          </div>

          <SheetFooter className="border-t border-border">
            <div className="flex flex-wrap justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                data-testid="authored-suite-preview"
                disabled={authoringLocked || unsavedScenarioReference || activeScenarioDirty}
                onClick={previewSuite}
              >
                {pending === "preview" ? (
                  <LoaderCircle className="animate-spin" />
                ) : (
                  <CheckCircle2 />
                )}
                {pending === "preview" ? "Checking..." : "Check suite"}
              </Button>
              <Button
                type="button"
                data-testid="authored-suite-save"
                disabled={authoringLocked || !previewCurrent || !suitePreview?.ready}
                onClick={saveSuite}
              >
                {pending === "save" ? <LoaderCircle className="animate-spin" /> : <Save />}
                {pending === "save" ? "Saving..." : "Save revision"}
              </Button>
              <Button
                type="button"
                variant="outline"
                data-testid="authored-suite-run-preview"
                disabled={
                  authoringLocked ||
                  !previewCurrent ||
                  savedRevision !== suitePreview?.suite.revision ||
                  selectedCaseKeys.size === 0 ||
                  launchCostBudgetInvalid
                }
                onClick={previewRun}
              >
                <CheckCircle2 /> Check launch
              </Button>
              <Button
                type="button"
                data-testid="authored-suite-launch"
                disabled={
                  authoringLocked ||
                  !runPreviewCurrent ||
                  !runPreview?.ready ||
                  !runPreview.exposure ||
                  launchCostBudgetInvalid
                }
                onClick={launch}
              >
                {pending === "launch" ? (
                  <LoaderCircle className="animate-spin" />
                ) : (
                  <FlaskConical />
                )}
                {pending === "launch" ? "Starting..." : "Run selected"}
              </Button>
            </div>
          </SheetFooter>
        </SheetContent>
      </Sheet>
    </>
  )
}

function SimpleInputEditor({
  evalCase,
  edit,
}: {
  evalCase: EvalCaseDraftV2
  edit: (evalCase: EvalCaseDraftV2) => void
}) {
  if (!("input" in evalCase.stimulus)) return null
  const messages = evalCase.stimulus.input.messages
  if (messages === undefined) {
    return (
      <Card size="sm" data-testid="authored-simple-input">
        <CardContent className="text-sm text-muted-foreground">
          This case uses runtime-owned opaque external input and cannot be edited in the Developer
          dashboard suite authoring.
        </CardContent>
      </Card>
    )
  }
  const updateMessages = (nextMessages: typeof messages) => {
    edit({
      ...evalCase,
      stimulus: { kind: "simple_input", input: { messages: nextMessages } },
    })
  }
  return (
    <Card size="sm" data-testid="authored-simple-input">
      <CardHeader className="grid-cols-[1fr_auto]">
        <div>
          <CardTitle>Input</CardTitle>
          <p className="mt-1 text-xs text-muted-foreground">
            Each message is supplied as ordered user input to one fresh agent session.
          </p>
        </div>
        <Button
          type="button"
          size="xs"
          variant="outline"
          disabled={messages.length >= 16}
          onClick={() =>
            updateMessages([...messages, { role: "user", text: "Add another user message." }])
          }
        >
          <Plus /> Add message
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {messages.map((message, index) => (
          // biome-ignore lint/suspicious/noArrayIndexKey: message rows hold no local state.
          <div key={`${index}:${messages.length}`} className="flex items-start gap-2">
            <Textarea
              rows={3}
              aria-label={`Case input message ${index + 1}`}
              value={message.text}
              onChange={(event) => {
                const next = [...messages]
                next[index] = { role: "user", text: event.target.value }
                updateMessages(next)
              }}
            />
            <Button
              type="button"
              size="icon-xs"
              variant="ghost"
              aria-label={`Remove case input message ${index + 1}`}
              disabled={messages.length === 1}
              onClick={() => updateMessages(messages.filter((_, candidate) => candidate !== index))}
            >
              <Trash2 />
            </Button>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function ReadinessSummary({
  title,
  ready,
  diagnostics,
  identity,
}: {
  title: string
  ready: boolean
  diagnostics: Array<{ case_id?: string | null; message: string }>
  identity: string
}) {
  return (
    <div
      className={`mt-4 rounded-lg border p-3 text-sm ${
        ready ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5"
      }`}
      data-testid="authored-suite-readiness"
    >
      <div className="font-medium">{title}</div>
      {diagnostics.map((diagnostic, index) => (
        // biome-ignore lint/suspicious/noArrayIndexKey: diagnostics are immutable preview rows.
        <div key={`${diagnostic.case_id ?? "suite"}:${index}`} className="mt-1 text-xs">
          {diagnostic.case_id ? `${diagnostic.case_id}: ` : ""}
          {diagnostic.message}
        </div>
      ))}
      <div className="mt-2 font-mono text-[11px] text-muted-foreground">
        {shortEvalIdentity(identity)}
      </div>
    </div>
  )
}

function RunExposureSummary({ exposure }: { exposure: EvalSuiteRunExposureV1 }) {
  return (
    <div
      className="mt-3 grid gap-2 rounded-lg border border-border bg-muted/20 p-3 text-xs @min-[28rem]/eval-form:grid-cols-2"
      data-testid="authored-suite-exposure"
    >
      <div>
        <span className="text-muted-foreground">Candidate work</span>
        <div className="font-medium">
          {exposure.candidate_trials.toLocaleString()} trials ·{" "}
          {exposure.maximum_candidate_model_steps == null
            ? "no model-step cap"
            : `up to ${exposure.maximum_candidate_model_steps.toLocaleString()} model steps`}{" "}
          ·{" "}
          {exposure.maximum_candidate_total_tokens == null
            ? "token ceiling unavailable"
            : `${exposure.maximum_candidate_total_tokens.toLocaleString()} tokens`}
        </div>
      </div>
      <div>
        <span className="text-muted-foreground">Judge work</span>
        <div className="font-medium">
          {exposure.judge_evaluations.toLocaleString()} evaluations ·{" "}
          {exposure.maximum_judge_total_tokens == null
            ? "token ceilings unavailable"
            : `up to ${exposure.maximum_judge_input_tokens?.toLocaleString()} input / ${exposure.maximum_judge_output_tokens?.toLocaleString()} output / ${exposure.maximum_judge_total_tokens.toLocaleString()} total tokens`}
        </div>
      </div>
      <div>
        <span className="text-muted-foreground">Maximum concurrency</span>
        <div className="font-medium">{exposure.max_concurrency.toLocaleString()}</div>
      </div>
      <div>
        <span className="text-muted-foreground">Maximum priced cost</span>
        <div className="font-medium">
          Candidate {formatCandidateExposureCost(exposure)} · judge{" "}
          {formatExposureCost(exposure.judge_cost)}
        </div>
      </div>
      <div className="font-mono text-[11px] text-muted-foreground @min-[28rem]/eval-form:col-span-2">
        Accepted exposure {shortEvalIdentity(exposure.revision)}
      </div>
    </div>
  )
}

function formatCandidateExposureCost(exposure: EvalSuiteRunExposureV1): string {
  const thresholds = [
    ...new Set(
      exposure.execution_profiles.flatMap((profile) => {
        const budget = profile.candidate_cost_budget
        return budget ? [`${budget.amount} ${budget.currency}`] : []
      }),
    ),
  ]
  const observedCeiling = formatExposureCost(exposure.candidate_cost)
  if (thresholds.length === 0) return observedCeiling
  return `${thresholds.join(" + ")} per-trial interruption threshold · ${observedCeiling}`
}

function formatExposureCost(exposure: EvalSuiteRunExposureV1["candidate_cost"]): string {
  if (exposure.state === "not_applicable") return "not applicable"
  if (exposure.state === "unavailable") {
    return exposure.unavailable_reason?.replaceAll("_", " ") ?? "unavailable"
  }
  return (exposure.totals ?? []).map((item) => `${item.amount} ${item.currency}`).join(" + ")
}

function Field({
  label,
  id,
  wide = false,
  children,
}: {
  label: string
  id: string
  wide?: boolean
  children: ReactNode
}) {
  return (
    <label htmlFor={id} className={wide ? "min-w-0 @min-[28rem]/eval-form:col-span-2" : "min-w-0"}>
      <span className={FIELD_LABEL}>{label}</span>
      {children}
    </label>
  )
}

function isScenarioCase(evalCase: EvalCaseDraftV2): evalCase is EvalCaseDraftV2 & {
  stimulus: { kind?: "scenario"; scenario_id: string; scenario_revision: string }
} {
  return "scenario_revision" in evalCase.stimulus
}

function withoutKey<T>(source: Record<string, T>, key: string): Record<string, T> {
  const next = { ...source }
  delete next[key]
  return next
}
