/**
 * The fake server behind today's Usage, Tasks, Environments, Artifacts and System pages.
 * Everything is derived from the current seed's records: environments from the sessions'
 * environment names, usage and cost from each session's usage and events, a task per root
 * session, and a few files the agent produced. Task holds and resumes live in memory.
 */
import type {
  ArtifactRead,
  ArtifactSummary,
  ArtifactsPage,
  EnvironmentSummary,
  EnvironmentsPage,
  OperationalSnapshot,
  PendingActionsPage,
  SessionsSummary,
  SystemDiagnostics,
  Task,
  UsageRollup,
} from "@/lib/api"
import type {
  AggregateAccuracy,
  AggregateCostSummary,
  AggregateUsageMetrics,
  ApiEventRecord,
  ApiSessionSummaryItem,
  LabelSelectorRequirement,
  SessionAggregateFilter,
  SessionCostSummary,
  SessionStatus,
  SessionStatusCounts,
  SessionUsageSummary,
  TaskAggregateFilter,
  TaskStatusCounts,
  UsageAggregateBreakdown,
  UsageAggregateTotals,
  UsageBreakdownItem,
  UsageCostRollup,
  UsageDimensionCostBreakdown,
  UsageSessionAggregateBreakdown,
  UsageSessionCostBreakdown,
  UsageSessionCostSummary,
  UsageSessionRanking,
  UsageTimeSeries,
} from "@/lib/generated/server-api"
import { resolveUsageWindow } from "@/lib/usage-rollup"
import type { TaskInfo, TaskItem, TaskScheduleEvent } from "../../api/types"
import { kindOf } from "../../routes/artifacts/artifact-model"
import type { AppSeed, SeedSession } from "../model"
import { inMockTimeWindow, mockTimeBuckets } from "../time-series"
import { CONTRACT } from "./contract"
import { HttpError, type LegacyContext, type LegacyRequest, type LegacyRoute } from "./server"

const iso = (ms: number) => new Date(ms).toISOString()
const EXACT: AggregateAccuracy = { kind: "exact", reason: null, limit: null }
/** The seed's costs stand in for a price book, so Usage shows estimates. */
const PRICE_BOOK = "prototype-seed-costs"

// ---------------------------------------------------------------------------------------
// Small readers for request bodies and query strings, which arrive untyped.

function record(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? Object.fromEntries(Object.entries(value))
    : {}
}

const text = (value: unknown) => (typeof value === "string" && value !== "" ? value : undefined)

function textRecord(value: unknown): Record<string, string> {
  return Object.fromEntries(
    Object.entries(record(value)).filter((e): e is [string, string] => typeof e[1] === "string"),
  )
}

function integer(query: URLSearchParams, key: string, fallback: number): number {
  const value = Number(query.get(key))
  return query.has(key) && Number.isInteger(value) && value >= 0 ? value : fallback
}

/** A deterministic hex string, so derived IDs read the same on every load. */
function hex(key: string, length: number): string {
  let h = 2166136261
  let out = ""
  while (out.length < length) {
    for (const c of `${key}:${out.length}`) h = Math.imul(h ^ c.charCodeAt(0), 16777619)
    out += (h >>> 0).toString(16).padStart(8, "0")
  }
  return out.slice(0, length)
}

const slug = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48) || "output"

// ---------------------------------------------------------------------------------------
// Sessions: status, filters and what the transcript says.

const SESSION_STATUSES: SessionStatus[] = [
  "pending",
  "running",
  "interrupting",
  "completed",
  "failed",
  "interrupted",
]

/** The runtime's status enum; the prototype calls a running session "active". */
function sessionStatus(s: SeedSession): SessionStatus {
  return SESSION_STATUSES.find((status) => status === s.session.status) ?? "running"
}

const LABEL_OPERATORS: LabelSelectorRequirement["operator"][] = [
  "in",
  "not_in",
  "exists",
  "not_exists",
]

function selectorFrom(value: unknown): LabelSelectorRequirement[] {
  const item = record(value)
  const key = text(item.key)
  const operator = LABEL_OPERATORS.find((op) => op === item.operator)
  if (!key || !operator) return []
  const values = Array.isArray(item.values)
    ? item.values.filter((v): v is string => typeof v === "string")
    : []
  return [{ key, operator, values }]
}

function filterFrom(value: unknown): SessionAggregateFilter {
  const body = record(value)
  return {
    agent_name: text(body.agent_name),
    provider_name: text(body.provider_name),
    model: text(body.model),
    environment_name: text(body.environment_name),
    parent_session_id: text(body.parent_session_id),
    causal_budget_id: text(body.causal_budget_id),
    labels: textRecord(body.labels),
    label_selectors: Array.isArray(body.label_selectors)
      ? body.label_selectors.flatMap(selectorFrom)
      : [],
  }
}

/** The same filter from `/sessions/summary`'s query; only exact `key=value` labels. */
function filterFromQuery(query: URLSearchParams): SessionAggregateFilter {
  const labels = query.getAll("label").flatMap((expression) => {
    const at = expression.indexOf("=")
    return at > 0 ? [[expression.slice(0, at), expression.slice(at + 1)]] : []
  })
  return filterFrom({
    ...Object.fromEntries(query.entries()),
    labels: Object.fromEntries(labels),
  })
}

function labelMatches(labels: Record<string, string>, selector: LabelSelectorRequirement) {
  const value = labels[selector.key]
  const values = selector.values ?? []
  if (selector.operator === "exists") return value !== undefined
  if (selector.operator === "not_exists") return value === undefined
  if (selector.operator === "in") return value !== undefined && values.includes(value)
  return value === undefined || !values.includes(value)
}

export function sessionMatches(s: SeedSession, filter: SessionAggregateFilter): boolean {
  const session = s.session
  const scalar: [string | null | undefined, string | null][] = [
    [filter.agent_name, session.agent_name],
    [filter.provider_name, session.provider_name],
    [filter.model, session.model],
    [filter.environment_name, session.environment_name],
    [filter.parent_session_id, session.parent_session_id],
    [filter.causal_budget_id, session.causal_budget_id],
  ]
  return (
    scalar.every(([want, got]) => want == null || want === got) &&
    Object.entries(filter.labels ?? {}).every(([key, value]) => session.labels[key] === value) &&
    (filter.label_selectors ?? []).every((selector) => labelMatches(session.labels, selector))
  )
}

function partsOf(s: SeedSession, role: string) {
  return s.transcript.filter((m) => m.role === role).flatMap((m) => m.content)
}

function textsOf(s: SeedSession, role: string): string[] {
  return partsOf(s, role).flatMap((p) =>
    p.type === "text" && typeof p.text === "string" ? [p.text] : [],
  )
}

const firstRequest = (s: SeedSession) => textsOf(s, "user")[0] ?? null
const lastReply = (s: SeedSession) => textsOf(s, "assistant").at(-1) ?? null
const titleOf = (s: SeedSession) => s.overview.title ?? firstRequest(s) ?? s.session.id

/** What the session submitted as structured output, if it did. */
function structuredOutput(s: SeedSession): unknown {
  for (const part of partsOf(s, "tool").reverse()) {
    const structured = record(part.structured)
    if ("output" in structured) return structured.output
  }
  return undefined
}

function toolCalls(s: SeedSession) {
  const results = new Map(
    partsOf(s, "tool").map((p) => [
      String(p.tool_call_id),
      { result: p.content, error: p.is_error },
    ]),
  )
  return partsOf(s, "assistant")
    .filter((p) => p.type === "tool_call" && !String(p.tool_name).startsWith("__cayu"))
    .map((p) => ({
      tool: String(p.tool_name),
      args: record(p.arguments),
      ...(results.get(String(p.tool_call_id)) ?? { result: null, error: false }),
    }))
}

// ---------------------------------------------------------------------------------------
// Tokens, as bigints so sums stay exact like the runtime's string counts.

type Tokens = {
  input: bigint
  output: bigint
  reasoning: bigint
  total: bigint
  cacheRead: bigint
  cached: bigint
  uncached: bigint
}

const NO_TOKENS: Tokens = {
  input: 0n,
  output: 0n,
  reasoning: 0n,
  total: 0n,
  cacheRead: 0n,
  cached: 0n,
  uncached: 0n,
}

const count = (value: string | undefined) => (value && /^\d+$/.test(value) ? BigInt(value) : 0n)

function tokensOf(usage: SessionUsageSummary): Tokens {
  const u = usage.usage
  return {
    input: count(u?.input_tokens),
    output: count(u?.output_tokens),
    reasoning: count(u?.reasoning_output_tokens),
    total: count(u?.total_tokens),
    cacheRead: count(u?.cache.read_tokens),
    cached: count(u?.cache.cached_input_tokens),
    uncached: count(u?.cache.uncached_input_tokens),
  }
}

function addTokens(a: Tokens, b: Tokens): Tokens {
  return {
    input: a.input + b.input,
    output: a.output + b.output,
    reasoning: a.reasoning + b.reasoning,
    total: a.total + b.total,
    cacheRead: a.cacheRead + b.cacheRead,
    cached: a.cached + b.cached,
    uncached: a.uncached + b.uncached,
  }
}

/** A share of a session's tokens: the part that fell inside a time window. */
function scaleTokens(t: Tokens, part: number, whole: number): Tokens {
  if (part === whole) return t
  const p = BigInt(part)
  const w = BigInt(Math.max(whole, 1))
  const input = (t.input * p) / w
  const output = (t.output * p) / w
  return {
    input,
    output,
    reasoning: (t.reasoning * p) / w,
    total: input + output,
    cacheRead: (t.cacheRead * p) / w,
    cached: (t.cached * p) / w,
    uncached: (t.uncached * p) / w,
  }
}

function metrics(t: Tokens): AggregateUsageMetrics {
  return {
    input_tokens: String(t.input),
    output_tokens: String(t.output),
    reasoning_output_tokens: String(t.reasoning),
    total_tokens: String(t.total),
    cache: {
      read_tokens: String(t.cacheRead),
      write_tokens: "0",
      write_5m_tokens: "0",
      write_1h_tokens: "0",
      write_unknown_ttl_tokens: "0",
      cached_input_tokens: String(t.cached),
      uncached_input_tokens: String(t.uncached),
    },
  }
}

function sessionUsage(s: SeedSession): SessionUsageSummary {
  return {
    session_id: s.session.id,
    model_steps: s.usage.model_steps ?? 0,
    tool_calls: s.usage.tool_calls ?? 0,
    unmeasured_model_attempts: 0,
    provider_names: s.usage.provider_names ?? [],
    models: s.usage.models ?? [],
    usage: metrics(tokensOf(s.usage)),
  }
}

// ---------------------------------------------------------------------------------------
// Activity: what each session did, whole or inside a usage window.

type Activity = {
  s: SeedSession
  tokens: Tokens
  steps: number
  tools: number
  /** Cost in millionths, or null when the seed has none for the session. */
  cost: number | null
  currency: string
}

function activityOf(s: SeedSession, window?: { start_at: string; end_at: string }): Activity {
  const inWindow = (e: ApiEventRecord) => {
    if (!window) return true
    return inMockTimeWindow(e.timestamp, window.start_at, window.end_at)
  }
  const steps = s.events.filter((e) => e.type === "model.completed")
  const stepsIn = steps.filter(inWindow).length
  const tools = s.events.filter((e) => e.type === "tool.call.started" && inWindow(e)).length
  const share = steps.length ? stepsIn / steps.length : 0
  const cost = s.overview.cost
  const totalTokens = tokensOf(s.usage)
  // Allocate integer remainders to stable synthetic events, so periods conserve totals.
  const windowTokens = window
    ? steps.reduce((sum, event, index) => {
        if (!inWindow(event)) return sum
        const before = scaleTokens(totalTokens, index, steps.length)
        const after = scaleTokens(totalTokens, index + 1, steps.length)
        return addTokens(sum, {
          input: after.input - before.input,
          output: after.output - before.output,
          reasoning: after.reasoning - before.reasoning,
          total: after.total - before.total,
          cacheRead: after.cacheRead - before.cacheRead,
          cached: after.cached - before.cached,
          uncached: after.uncached - before.uncached,
        })
      }, NO_TOKENS)
    : totalTokens
  return {
    s,
    tokens: windowTokens,
    steps: window ? stepsIn : (s.usage.model_steps ?? steps.length),
    tools: window ? tools : (s.usage.tool_calls ?? tools),
    cost: cost ? Math.round(cost.amount * 1e6 * (window ? share : 1)) : null,
    currency: cost?.currency ?? "USD",
  }
}

const active = (a: Activity) => a.steps > 0 || a.tools > 0
const money = (millionths: number) => (millionths / 1e6).toFixed(6)

function totalsOf(acts: Activity[]): UsageAggregateTotals {
  const steps = acts.reduce((n, a) => n + a.steps, 0)
  return {
    session_count: String(acts.filter(active).length),
    model_steps: String(steps),
    model_steps_with_usage: String(steps),
    tool_calls: String(acts.reduce((n, a) => n + a.tools, 0)),
    usage: metrics(acts.reduce((t, a) => addTokens(t, a.tokens), NO_TOKENS)),
  }
}

/** Groups by a key, largest token total first. */
function groupBy(acts: Activity[], key: (a: Activity) => string) {
  const groups = new Map<string, Activity[]>()
  for (const a of acts) groups.set(key(a), [...(groups.get(key(a)) ?? []), a])
  const total = (list: Activity[]) => list.reduce((t, a) => t + a.tokens.total, 0n)
  return [...groups.values()].sort((a, b) => (total(b) > total(a) ? 1 : -1))
}

function usageBreakdown(
  acts: Activity[],
  limit: number,
  withModel: boolean,
): UsageAggregateBreakdown {
  const groups = groupBy(acts.filter(active), (a) =>
    withModel
      ? JSON.stringify([a.s.session.provider_name, a.s.session.model])
      : `${a.s.session.provider_name}`,
  )
  const rest = groups.slice(limit)
  return {
    accuracy: rest.length
      ? { kind: "truncated", reason: "Other groups are included in the remainder.", limit }
      : EXACT,
    groups: groups.slice(0, limit).map((list) => ({
      provider_name: list[0]?.s.session.provider_name ?? null,
      model: withModel ? (list[0]?.s.session.model ?? null) : null,
      totals: totalsOf(list),
    })),
    remainder: rest.length
      ? { group_count: String(rest.length), totals: totalsOf(rest.flat()) }
      : null,
  }
}

function costSummary(acts: Activity[]): UsageSessionCostSummary {
  const priced = acts.filter((a) => a.cost !== null && a.steps > 0)
  const pricedSteps = priced.reduce((n, a) => n + a.steps, 0)
  const unpriced = acts.reduce((n, a) => n + a.steps, 0) - pricedSteps
  return {
    accuracy: EXACT,
    currencies: groupBy(priced, (a) => a.currency).map((list) => ({
      currency: list[0]?.currency ?? "USD",
      model_steps: String(list.reduce((n, a) => n + a.steps, 0)),
      total_cost: money(list.reduce((n, a) => n + (a.cost ?? 0), 0)),
    })),
    evaluated_model_steps: String(pricedSteps + unpriced),
    priced_model_steps: String(pricedSteps),
    unevaluated_model_steps: "0",
    unpriced_model_steps: String(unpriced),
    unpriced_reasons: unpriced
      ? [
          {
            model_steps: String(unpriced),
            reason: "No price for this model.",
            unpriced_reason: "missing_pricing",
          },
        ]
      : [],
  }
}

function costRollup(acts: Activity[], seed: AppSeed): UsageCostRollup {
  return {
    ...costSummary(acts.filter(active)),
    billing_breakdown: {
      accuracy: EXACT,
      groups: [],
      identified_model_steps: "0",
      remainder: null,
    },
    price_book_version: PRICE_BOOK,
    price_book_generated_at: seed.now,
  }
}

const seedHasCosts = (seed: AppSeed) => seed.sessions.some((s) => s.overview.cost !== null)

// ---------------------------------------------------------------------------------------
// POST /usage/rollup

/**
 * The Usage page anchors its window on the browser's clock. A window that ends about now
 * is moved onto the seed's clock, so "Last 30 days" covers the seed's sessions; a custom
 * window is used as given.
 */
function usageWindow(body: Record<string, unknown>, context: LegacyContext) {
  const start = Date.parse(String(body.start_at))
  const end = Date.parse(String(body.end_at))
  try {
    resolveUsageWindow({
      range: "custom",
      start_at: String(body.start_at),
      end_at: String(body.end_at),
    })
  } catch {
    throw new HttpError(422, "start_at and end_at must be timestamps, with start before end.")
  }
  const relative = !body.series && Math.abs(end - Date.now()) < 10 * 60_000
  const shift = relative ? context.now() - Date.now() : 0
  return {
    start: start + shift,
    end: end + shift,
    start_at: shift ? iso(start + shift) : String(body.start_at),
    end_at: shift ? iso(end + shift) : String(body.end_at),
  }
}

function sessionBreakdown(
  acts: Activity[],
  limit: number,
  order: "tokens" | "cost",
): UsageSessionAggregateBreakdown {
  const ranked = [...acts].sort((a, b) => {
    if (order === "cost" && a.cost !== b.cost) return (b.cost ?? 0) - (a.cost ?? 0)
    if (a.tokens.total !== b.tokens.total) return b.tokens.total > a.tokens.total ? 1 : -1
    return b.steps - a.steps || a.s.session.id.localeCompare(b.s.session.id)
  })
  const rest = ranked.slice(limit)
  const isActive = (a: Activity) =>
    ["running", "pending", "interrupting"].includes(sessionStatus(a.s))
  return {
    order,
    accuracy: rest.length
      ? { kind: "truncated", reason: "Matching sessions exceed session_group_limit.", limit }
      : EXACT,
    groups: ranked.slice(0, limit).map((a) => ({
      session_id: a.s.session.id,
      title: a.s.overview.title ?? null,
      agent_name: a.s.session.agent_name,
      status: sessionStatus(a.s),
      active: isActive(a),
      totals: totalsOf([a]),
    })),
    remainder: rest.length
      ? {
          group_count: String(rest.length),
          active_session_count: String(rest.filter(isActive).length),
          totals: totalsOf(rest),
        }
      : null,
  }
}

/** Fake estimates use the seed's made-up costs, not a second pricing engine. */
function dimensionCosts(
  acts: Activity[],
  breakdown: UsageAggregateBreakdown,
  seed: AppSeed,
  withModel: boolean,
): UsageDimensionCostBreakdown {
  const selected = new Set<Activity>()
  const groups = breakdown.groups.map((group) => {
    const rows = acts.filter(
      (a) =>
        active(a) &&
        (a.s.session.provider_name ?? null) === group.provider_name &&
        (!withModel || (a.s.session.model ?? null) === group.model),
    )
    for (const row of rows) selected.add(row)
    return { provider_name: group.provider_name, model: group.model, cost: costSummary(rows) }
  })
  return {
    accuracy: breakdown.accuracy,
    price_book_version: PRICE_BOOK,
    price_book_generated_at: seed.now,
    groups,
    remainder: breakdown.remainder
      ? {
          group_count: breakdown.remainder.group_count,
          cost: costSummary(acts.filter((a) => active(a) && !selected.has(a))),
        }
      : null,
  }
}

function usageRollup({ body: raw }: LegacyRequest, context: LegacyContext): UsageRollup {
  const seed = context.records()
  const body = record(raw)
  const window = usageWindow(body, context)
  const filter = filterFrom(body.session_filter)
  const matching = seed.sessions.filter((s) => sessionMatches(s, filter))
  const acts = matching.map((s) => activityOf(s, window))
  const spec = record(body.series)
  const series: UsageTimeSeries | null =
    spec.unit === "hour" || spec.unit === "day" || spec.unit === "week"
      ? {
          unit: spec.unit,
          timezone: typeof spec.timezone === "string" ? spec.timezone : "UTC",
          buckets: mockTimeBuckets(
            String(body.start_at),
            String(body.end_at),
            spec.unit,
            typeof spec.timezone === "string" ? spec.timezone : "UTC",
          ).map((bucket) => ({
            start_at: bucket.start_at,
            end_at: bucket.end_at,
            totals: totalsOf(matching.map((session) => activityOf(session, bucket))),
          })),
        }
      : null
  const groupLimit = Math.max(1, Number(body.group_limit) || 20)
  const sessionLimit = Number(body.session_group_limit) || 0
  const costs = seedHasCosts(seed)
  const requestedOrder = body.session_order === "cost" ? "cost" : "tokens"
  const currencies = new Set(
    acts.filter((a) => a.steps > 0 && a.cost !== null).map((a) => a.currency),
  )
  const reason: UsageSessionRanking["unavailable_reason"] =
    requestedOrder === "tokens"
      ? null
      : !costs
        ? "pricing_not_configured"
        : matching.length > 1000
          ? "candidate_limit"
          : acts.some((a) => a.steps > 0 && a.cost === null)
            ? "prices_incomplete"
            : currencies.size > 1
              ? "mixed_currencies"
              : null
  const order = requestedOrder === "cost" && reason === null ? "cost" : "tokens"
  const sessions = sessionLimit > 0 ? sessionBreakdown(acts, sessionLimit, order) : null
  const providers = usageBreakdown(acts, groupLimit, false)
  const models = usageBreakdown(acts, groupLimit, true)
  // Like the server, session costs cover the same sessions, in the same order, as session usage.
  const alignedCosts = (usage: UsageSessionAggregateBreakdown): UsageSessionCostBreakdown => {
    const kept = new Set(usage.groups.map((g) => g.session_id))
    const byId = new Map(acts.map((a) => [a.s.session.id, a]))
    const rest = acts.filter((a) => !kept.has(a.s.session.id))
    return {
      accuracy: usage.accuracy,
      price_book_version: PRICE_BOOK,
      price_book_generated_at: seed.now,
      groups: usage.groups.flatMap((g) => {
        const a = byId.get(g.session_id)
        return a ? [{ session_id: g.session_id, cost: costSummary([a]) }] : []
      }),
      remainder: rest.length ? { group_count: String(rest.length), cost: costSummary(rest) } : null,
    }
  }
  return {
    scope: "configured_session_store",
    time_basis: "event.timestamp",
    session_filter_basis: "current_session_attributes",
    as_of: iso(context.now()),
    start_at: body.series ? String(body.start_at) : iso(window.start),
    end_at: body.series ? String(body.end_at) : iso(window.end),
    accuracy: EXACT,
    matching_session_count: String(matching.length),
    active_session_count: String(matching.filter((s) => sessionStatus(s) === "running").length),
    includes_active_sessions: true,
    totals: totalsOf(acts),
    series,
    provider_breakdown: providers,
    model_breakdown: models,
    provider_cost_breakdown: costs ? dimensionCosts(acts, providers, seed, false) : null,
    model_cost_breakdown: costs ? dimensionCosts(acts, models, seed, true) : null,
    session_ranking: sessions
      ? {
          requested_order: requestedOrder,
          effective_order: order,
          unavailable_reason: reason,
          currency: order === "cost" ? ([...currencies][0] ?? null) : null,
        }
      : null,
    cost: costs ? costRollup(acts, seed) : null,
    reported_costs: { records: [], truncated: false },
    session_breakdown: sessions,
    session_cost_breakdown: sessions && costs ? alignedCosts(sessions) : null,
  }
}

// ---------------------------------------------------------------------------------------
// POST /sessions/summary (Environments lists an environment's latest sessions)

function summaryItem(s: SeedSession): ApiSessionSummaryItem {
  const counts: Record<string, number> = {}
  for (const e of s.events) counts[e.type] = (counts[e.type] ?? 0) + 1
  const latest = s.events.at(-1) ?? null
  const terminal =
    latest && ["session.completed", "session.failed", "session.interrupted"].includes(latest.type)
      ? latest
      : null
  return {
    session: { ...s.session, metadata: s.metadata },
    events: { counts_by_type: counts, latest_event: latest, total_events: s.events.length },
    outcome: {
      session_id: s.session.id,
      status: s.session.status,
      reason: s.overview.reason,
      details: {},
      retry: null,
      latest_retry_event: null,
      terminal_event: terminal,
    },
  }
}

function breakdownItems(acts: Activity[], withModel: boolean): UsageBreakdownItem[] {
  return usageBreakdown(acts, Number.MAX_SAFE_INTEGER, withModel).groups.map((g) => ({
    provider_name: g.provider_name,
    model: g.model,
    session_count: Number(g.totals.session_count),
    model_steps: Number(g.totals.model_steps),
    usage: g.totals.usage,
  }))
}

function sessionCost(a: Activity): SessionCostSummary {
  return {
    session_id: a.s.session.id,
    currency: a.currency,
    model_steps: a.steps,
    priced_model_steps: a.cost === null ? 0 : a.steps,
    unpriced_model_steps: a.cost === null ? a.steps : 0,
    total_cost: money(a.cost ?? 0),
  }
}

function aggregateCost(acts: Activity[]): AggregateCostSummary | null {
  const costs = acts.map(sessionCost)
  if (!acts.some((a) => a.cost !== null)) return null
  return {
    currency: acts[0]?.currency ?? "USD",
    line_items: [],
    session_costs: costs,
    session_count: acts.length,
    session_ids: acts.map((a) => a.s.session.id),
    model_steps: costs.reduce((n, c) => n + c.model_steps, 0),
    priced_model_steps: costs.reduce((n, c) => n + c.priced_model_steps, 0),
    unpriced_model_steps: costs.reduce((n, c) => n + c.unpriced_model_steps, 0),
    total_cost: money(acts.reduce((n, a) => n + (a.cost ?? 0), 0)),
  }
}

const SESSION_ORDERS: Record<string, (s: SeedSession) => string> = {
  created_at: (s) => s.session.created_at,
  updated_at: (s) => s.session.updated_at,
  last_activity_at: (s) => s.overview.last_activity_at,
}

function sessionsSummary({ query }: LegacyRequest, context: LegacyContext): SessionsSummary {
  const filter = filterFromQuery(query)
  const q = query.get("q")?.toLowerCase()
  const status = query.get("status")
  const order = query.get("order_by") ?? "created_at_desc"
  const field = SESSION_ORDERS[order.replace(/_(asc|desc)$/, "")] ?? SESSION_ORDERS.created_at
  const direction = order.endsWith("_asc") ? 1 : -1
  const matching = context
    .records()
    .sessions.filter(
      (s) =>
        sessionMatches(s, filter) &&
        (!status || sessionStatus(s) === status) &&
        (!q || `${s.session.id} ${s.session.agent_name} ${titleOf(s)}`.toLowerCase().includes(q)),
    )
    .sort((a, b) => direction * (field?.(a) ?? "").localeCompare(field?.(b) ?? ""))
  const offset = integer(query, "offset", 0)
  const page = matching.slice(offset, offset + integer(query, "limit", 50))
  const acts = page.map((s) => activityOf(s))
  const total = totalsOf(acts)
  return {
    session_count: page.length,
    total_count: matching.length,
    next_cursor: null,
    sessions: page.map(summaryItem),
    usage: {
      session_ids: page.map((s) => s.session.id),
      session_count: page.length,
      model_steps: Number(total.model_steps),
      unmeasured_model_attempts: 0,
      tool_calls: Number(total.tool_calls),
      provider_names: [...new Set(page.flatMap((s) => s.usage.provider_names ?? []))],
      models: [...new Set(page.flatMap((s) => s.usage.models ?? []))],
      usage: total.usage,
      session_summaries: page.map(sessionUsage),
    },
    provider_breakdown: breakdownItems(acts, false),
    model_breakdown: breakdownItems(acts, true),
    cost: aggregateCost(acts),
  }
}

// ---------------------------------------------------------------------------------------
// Tasks: the seed's own, plus one per root session that has none. Holds live in memory.

const HELD = new Set(["paused", "blocked", "needs_attention"])
const TERMINAL = new Set(["completed", "failed", "cancelled", "dependency_skipped"])

type TaskChange = Pick<Task, "status" | "status_reason" | "status_payload" | "updated_at"> & {
  /** The status before a hold, which resume returns to while the work is still live. */
  before: string
}
const changes = new WeakMap<AppSeed, Map<string, TaskChange>>()

function changesFor(seed: AppSeed) {
  let map = changes.get(seed)
  if (!map) {
    map = new Map()
    changes.set(seed, map)
  }
  return map
}

/** A session's task follows its state; a waiting session's task is still running. */
function taskStatusOf(seed: AppSeed, s: SeedSession): { status: string; reason: string | null } {
  const state = s.overview.state
  if (state === "completed") return { status: "completed", reason: null }
  if (state === "failed") return { status: "failed", reason: s.overview.reason }
  if (state === "interrupted") return { status: "paused", reason: "The session was interrupted." }
  if (state === "needs_recovery") {
    const item = seed.inbox.find((i) => i.session_id === s.session.id && i.kind === "recovery")
    const reason = item?.detail ?? s.overview.reason ?? "The session needs recovery."
    return { status: "needs_attention", reason }
  }
  return { status: "running", reason: null }
}

function taskTypeOf(seed: AppSeed, agent: string) {
  const types = seed.taskTypes ?? []
  return (types.find((t) => t.agent_name === agent) ?? types[0])?.name ?? "session_request"
}

function sessionTask(seed: AppSeed, s: SeedSession, now: number): Task {
  const { status, reason } = taskStatusOf(seed, s)
  const created = Date.parse(s.session.created_at) - 2_000
  const live = status === "running"
  return {
    id: `task_${hex(s.session.id, 20)}`,
    type: taskTypeOf(seed, s.session.agent_name),
    title: titleOf(s),
    description: null,
    status,
    // Like the runtime, a failure's reason is its error's summary, not a status reason.
    status_reason: status === "failed" ? null : reason,
    status_payload: null,
    error_summary: status === "failed" ? reason : null,
    session_id: s.session.id,
    graph_id: null,
    prerequisite_task_ids: [],
    parent_task_id: null,
    assigned_agent_name: s.session.agent_name,
    available_at: iso(created),
    worker_id: live || TERMINAL.has(status) ? "worker-local-1" : null,
    lease_expires_at: live ? iso(now + 60_000) : null,
    created_at: iso(created),
    updated_at: s.overview.ended_at ?? s.overview.last_activity_at,
    completed_at: TERMINAL.has(status) ? s.overview.ended_at : null,
    retry_series: null,
    schedule: null,
  }
}

/** Every task, the seed's first; the new Tasks page reads these too. */
export function taskList(context: LegacyContext): TaskItem[] {
  const seed = context.records()
  const covered = new Set(seed.tasks.map((t) => t.session_id))
  const derived = seed.sessions
    .filter((s) => !s.session.parent_session_id && !covered.has(s.session.id))
    .map((s) => sessionTask(seed, s, context.now()))
  const held = changesFor(seed)
  return [...seed.tasks, ...derived].map((task) => {
    const change = held.get(task.id)
    if (!change) return task
    const { before: _, ...rest } = change
    return { ...task, ...rest }
  })
}

function findTask(context: LegacyContext, id: string): TaskItem {
  const task = taskList(context).find((t) => t.id === id)
  if (!task) throw new HttpError(404, `Task ${id} was not found.`)
  return task
}

function taskDetail(context: LegacyContext, task: TaskItem): TaskInfo {
  const s = context.records().sessions.find((x) => x.session.id === task.session_id)
  const request = s ? firstRequest(s) : null
  const output = s ? structuredOutput(s) : undefined
  const input = context.records().taskInputs?.[task.id] ?? {}
  return {
    ...task,
    started_at: s?.session.created_at ?? null,
    input: request && Object.keys(input).length === 0 ? { request, ...s?.session.labels } : input,
    result:
      task.status === "completed" && s
        ? {
            summary: s.overview.summary,
            reply: lastReply(s),
            ...(output === undefined ? {} : { output }),
          }
        : null,
    error:
      task.status === "failed" || task.status === "dependency_skipped"
        ? { message: task.error_summary ?? task.status_reason ?? s?.overview.reason ?? null }
        : null,
    invocation: {
      schema_version: 1,
      source: "task_dispatch",
      origin: { subject: null, tenant: null, trust: "unattributed" },
      root_invocation_id: `inv_${hex(task.id, 20)}`,
      root_session_id: task.session_id,
    },
    metadata: s ? { session_labels: s.session.labels } : {},
  }
}

function taskMatches(task: Task, query: URLSearchParams): boolean {
  const q = query.get("q")?.toLowerCase()
  const exact = ["status", "type", "session_id", "parent_task_id", "assigned_agent_name"] as const
  const types = query.getAll("types")
  return (
    exact.every((key) => !query.get(key) || task[key] === query.get(key)) &&
    (!types.length || types.includes(task.type)) &&
    (!q ||
      [task.id, task.type, task.title, task.status, task.session_id, task.assigned_agent_name]
        .join(" ")
        .toLowerCase()
        .includes(q))
  )
}

function listTasks({ query }: LegacyRequest, context: LegacyContext): TaskItem[] {
  const order = query.get("order_by") ?? "updated_at_desc"
  const field = order.startsWith("created_at") ? "created_at" : "updated_at"
  const direction = order.endsWith("_asc") ? 1 : -1
  const offset = integer(query, "offset", 0)
  return taskList(context)
    .filter((task) => taskMatches(task, query))
    .sort((a, b) => direction * a[field].localeCompare(b[field]))
    .slice(offset, offset + integer(query, "limit", 100))
}

export function taskInfo(context: LegacyContext, id: string): TaskInfo {
  return taskDetail(context, findTask(context, id))
}

/** Pause, block or flag a task; finished tasks and running session tasks can't be held. */
export function holdTask(
  context: LegacyContext,
  id: string,
  status: "paused" | "blocked" | "needs_attention",
  hold: Record<string, unknown> = {},
): TaskInfo {
  const task = findTask(context, id)
  if (TERMINAL.has(task.status) || (task.status === "running" && task.session_id)) {
    throw new HttpError(409, `Task ${task.id} is ${task.status} and can't be held.`)
  }
  const held = changesFor(context.records())
  held.set(task.id, {
    status,
    status_reason: text(hold.reason) ?? null,
    status_payload: hold.payload ? record(hold.payload) : null,
    updated_at: iso(context.now()),
    before: held.get(task.id)?.before ?? task.status,
  })
  return taskInfo(context, task.id)
}

/** Resume returns a held task to its work: running if it was, otherwise pending. */
export function resumeTask(context: LegacyContext, id: string): TaskInfo {
  const task = findTask(context, id)
  if (!HELD.has(task.status)) {
    throw new HttpError(409, `Task ${task.id} is ${task.status}, not held.`)
  }
  const held = changesFor(context.records())
  const before = held.get(task.id)?.before
  held.set(task.id, {
    status: before === "running" || before === "claimed" ? before : "pending",
    status_reason: null,
    status_payload: null,
    updated_at: iso(context.now()),
    before: before ?? task.status,
  })
  return taskInfo(context, task.id)
}

/** A scheduled task's history: admitted when created, then whatever happened since. */
export function scheduleEvents(context: LegacyContext, id: string): TaskScheduleEvent[] {
  const task = findTask(context, id)
  const schedule = task.schedule
  if (!schedule) return []
  const at = task.available_at ?? task.created_at
  const types: TaskScheduleEvent["type"][] = ["task.scheduled"]
  if (schedule.revision > 1) types.push("task.rescheduled")
  if (Date.parse(at) <= context.now() || task.status !== "pending")
    types.push("task.schedule_eligible")
  if (["claimed", "running", "completed", "failed"].includes(task.status))
    types.push("task.schedule_claimed", "task.schedule_started")
  if (task.status === "completed") types.push("task.schedule_completed")
  if (task.status === "failed") types.push("task.schedule_failed")
  if (task.status === "cancelled") types.push("task.schedule_cancelled")
  if (HELD.has(task.status)) types.push("task.schedule_held")
  const times = [Date.parse(task.created_at), Date.parse(at), Date.parse(task.updated_at)]
  return types.map((type, i) => ({
    sequence: i + 1,
    type,
    task_id: task.id,
    revision: type === "task.scheduled" ? 1 : schedule.revision,
    available_at: at,
    occurred_at: iso(
      type === "task.scheduled"
        ? (times[0] ?? 0)
        : type === "task.rescheduled"
          ? (times[0] ?? 0) + 3_600_000
          : type === "task.schedule_eligible"
            ? (times[1] ?? 0)
            : (times[2] ?? 0),
    ),
    operation_id: type === "task.rescheduled" ? `op_${hex(task.id, 12)}` : null,
    invocation_id: `inv_${hex(task.id, 20)}`,
    policy: schedule.policy,
  }))
}

// ---------------------------------------------------------------------------------------
// POST /operations/snapshot

/** How many values equal `key`, as the runtime's string count. */
const tally = (values: string[], key: string) => String(values.filter((v) => v === key).length)

function sessionCounts(statuses: string[]): SessionStatusCounts {
  const [pending, running, interrupting, completed, failed, interrupted] = SESSION_STATUSES.map(
    (key) => tally(statuses, key),
  )
  return {
    pending: pending ?? "0",
    running: running ?? "0",
    interrupting: interrupting ?? "0",
    completed: completed ?? "0",
    failed: failed ?? "0",
    interrupted: interrupted ?? "0",
  }
}

function taskCounts(statuses: string[]): TaskStatusCounts {
  const n = (key: string) => tally(statuses, key)
  return {
    pending: n("pending"),
    waiting_dependencies: n("waiting_dependencies"),
    waiting_group: n("waiting_group"),
    dependency_skipped: n("dependency_skipped"),
    claimed: n("claimed"),
    running: n("running"),
    paused: n("paused"),
    blocked: n("blocked"),
    needs_attention: n("needs_attention"),
    completed: n("completed"),
    failed: n("failed"),
    cancelled: n("cancelled"),
  }
}

function taskFilterFrom(value: unknown): TaskAggregateFilter {
  const body = record(value)
  return {
    type: text(body.type),
    session_id: text(body.session_id),
    parent_task_id: text(body.parent_task_id),
    assigned_agent_name: text(body.assigned_agent_name),
  }
}

function operationsSnapshot(
  { body: raw }: LegacyRequest,
  context: LegacyContext,
): OperationalSnapshot {
  const body = record(raw)
  const asOf = iso(context.now())
  const filter = filterFrom(body.session_filter)
  const sessions = context.records().sessions.filter((s) => sessionMatches(s, filter))
  const includeTasks = body.include_tasks !== false
  const taskFilter = taskFilterFrom(body.task_filter)
  const tasks = taskList(context).filter((task) =>
    (["type", "session_id", "parent_task_id", "assigned_agent_name"] as const).every(
      (key) => taskFilter[key] == null || task[key] === taskFilter[key],
    ),
  )
  const pending = tasks.filter((t) => t.status === "pending")
  const scheduled = pending.filter(
    (t) => t.available_at && Date.parse(t.available_at) > context.now(),
  )
  return {
    scope: "configured_stores",
    cross_store_atomic: false,
    sessions: {
      as_of: asOf,
      total_count: String(sessions.length),
      counts_by_status: sessionCounts(sessions.map(sessionStatus)),
      accuracy: EXACT,
    },
    task_snapshot_status: includeTasks ? "available" : "not_requested",
    tasks: includeTasks
      ? {
          as_of: asOf,
          total_count: String(tasks.length),
          counts_by_status: taskCounts(tasks.map((t) => t.status)),
          claimable_pending_count: String(pending.length - scheduled.length),
          scheduled_pending_count: String(scheduled.length),
          accuracy: EXACT,
        }
      : null,
  }
}

// ---------------------------------------------------------------------------------------
// Environments and system diagnostics, after a real `cayu serve --dev` capture.

/**
 * Environments registered without sessions yet, so the list has more than one shape: an
 * AWS Lambda microVM sandbox made fresh per session, and a shared Docker container. A
 * seed with no sessions (a new agent) keeps only the default `local` environment.
 */
const EXTRA_ENVIRONMENTS = ["docker-dev", "sandbox"]

function environmentNames(seed: AppSeed): string[] {
  const names = new Set(seed.sessions.flatMap((s) => s.session.environment_name ?? []))
  if (!names.size) return ["local"]
  for (const name of EXTRA_ENVIRONMENTS) names.add(name)
  return [...names].sort()
}

const storeOf = (environment: string) =>
  environment === "local" ? "standard-local-artifacts" : `${environment}-artifacts`

const NO_BRANCHES: EnvironmentSummary["workspace_branch_capabilities"] = {
  isolation: false,
  net_changes: false,
  publication: "unsupported",
  recovery: "unsupported",
  retention: "unsupported",
  lifecycle_inspection: "unsupported",
  detail_code: "workspace_branching_unsupported",
}

/** Branches on a workspace reached through a runner (`RunnerWorkspace`), as the runtime reports them. */
const RUNNER_BRANCHES: EnvironmentSummary["workspace_branch_capabilities"] = {
  isolation: true,
  net_changes: true,
  publication: "cooperative_atomic",
  recovery: "process_local",
  retention: "process_local",
  lifecycle_inspection: "attached",
  detail_code: "process_local_remote_runner_workspace_branches",
}

const DURABLE_RUNNER_BRANCHES: EnvironmentSummary["workspace_branch_capabilities"] = {
  ...RUNNER_BRANCHES,
  recovery: "durable",
  retention: "durable",
  lifecycle_inspection: "recoverable_by_id",
  detail_code: "durable_remote_runner_workspace_branches",
}

const NO_SNAPSHOTS: EnvironmentSummary["execution_snapshot_capability"] = {
  fidelity: "unsupported",
  adapter: "unsupported",
  adapter_version: "1",
  snapshot_format: "none",
  compatibility_sha256: null,
  requires_managed_launch: false,
}

/** What differs from the default local environment, by environment name. */
const ENVIRONMENT_PROFILES: Record<string, Partial<EnvironmentSummary>> = {
  checkout: {
    metadata: { profile: "pr-checkout-v2", repository: "cayu-tech/cayu" },
    workspace_id: "checkout-repo",
    runner_type: "DockerRunner",
    binding_type: "GitRepositoryBinding",
    vault_type: "LocalEnvVault",
    proxy_type: "AllowlistProxy",
    knowledge_store_type: "PostgresKnowledgeStore",
    mcp_server_count: 2,
    mcp_server_names: ["Repository search", "Issue tracker"],
    lifecycle_policy: {
      lifecycle_timeout_seconds: 600,
      phase_timeout_seconds: { bind: 180, materialize: 300 },
      max_progress_events: 64,
      progress_min_interval_seconds: 2,
    },
    workspace_instructions:
      "The pull request is checked out at /workspace. Run the repository's own checks before commenting.",
  },
  "docker-dev": {
    metadata: { profile: "docker-dev-v1", image: "cayu/dev:2026.10" },
    workspace_id: "docker-dev-workspace",
    workspace_branch_capabilities: RUNNER_BRANCHES,
    runner_type: "DockerRunner",
    binding_type: "NativeBinding",
    vault_type: "LocalEnvVault",
    proxy_type: "PassthroughProxy",
    knowledge_store_type: "SQLiteKnowledgeStore",
    mcp_server_count: 1,
    mcp_server_names: ["Local docs"],
  },
  // Created for each session by a factory, as `register_environment_factory` reports it: the
  // registration has no runner, workspace or stores; each session's environment does.
  "invoice-checkout": {
    metadata: {},
    is_factory: true,
    factory_type: "InvoiceCheckoutFactory",
    artifact_store_id: null,
    artifact_store_kind: null,
    knowledge_store_type: null,
  },
  sandbox: {
    metadata: { profile: "aws-lambda-microvm-v1", region: "us-west-2" },
    is_factory: true,
    factory_type: "MicroVMSandboxFactory",
    workspace_id: "sandbox-workspace",
    workspace_branch_capabilities: DURABLE_RUNNER_BRANCHES,
    runner_type: "LambdaMicroVMRunner",
    binding_type: "NativeBinding",
    vault_type: "SecretsManagerVault",
    proxy_type: "AllowlistProxy",
    knowledge_store_type: "PostgresEmbeddingKnowledgeStore",
    mcp_server_count: 3,
    mcp_server_names: ["Knowledge lookup", "Metrics", "Release notes"],
    artifact_store_kind: "s3",
    execution_snapshot_capability: {
      fidelity: "filesystem",
      adapter: "lambda-microvm",
      adapter_version: "3",
      snapshot_format: "ext4-delta",
      compatibility_sha256: hex("sandbox-snapshot", 64),
      requires_managed_launch: true,
    },
    lifecycle_policy: {
      lifecycle_timeout_seconds: 900,
      phase_timeout_seconds: { provision: 300, bind: 120 },
      max_progress_events: 128,
      progress_min_interval_seconds: 1,
    },
    workspace_instructions: "Work inside /workspace. Network access is limited to the allowlist.",
  },
}

/** Whether the environment's registration names a file store (a factory's may not). */
const hasFileStore = (name: string) => ENVIRONMENT_PROFILES[name]?.artifact_store_id !== null

function environment(name: string, seed: AppSeed, now: number): EnvironmentSummary {
  const sessions = seed.sessions.filter((s) => s.session.environment_name === name)
  const last = sessions.reduce<string | null>(
    (latest, s) =>
      !latest || Date.parse(s.overview.last_activity_at) > Date.parse(latest)
        ? s.overview.last_activity_at
        : latest,
    null,
  )
  const profile = ENVIRONMENT_PROFILES[name] ?? {}
  // Branches the agent's code still has open; the fake counts one per running or waiting session.
  const open = profile.workspace_branch_capabilities?.isolation
    ? seed.sessions.filter(
        (s) =>
          s.session.environment_name === name &&
          !["completed", "failed", "interrupted"].includes(s.overview.state),
      ).length
    : 0
  return {
    name,
    metadata: { profile: "standard-local-v1", runner: "unavailable", network: "unavailable" },
    is_factory: false,
    factory_type: null,
    workspace_id: null,
    workspace_branch_capabilities: NO_BRANCHES,
    artifact_store_id: storeOf(name),
    artifact_store_kind: "local_disk",
    session_count: String(sessions.length),
    last_activity_at: last,
    activity_as_of: new Date(now).toISOString(),
    runner_type: null,
    binding_type: null,
    vault_type: null,
    proxy_type: null,
    knowledge_store_type: "SQLiteKnowledgeStore",
    mcp_server_count: 0,
    mcp_server_names: [],
    workspace_checkpoint_policy: null,
    execution_snapshot_capability: NO_SNAPSHOTS,
    lifecycle_policy: null,
    workspace_instructions: null,
    bound_workspace: null,
    ...profile,
    workspace_branch_lifecycle: {
      attached_count: open,
      statuses: open ? ["active"] : [],
      truncated: false,
    },
  }
}

function environments(_: LegacyRequest, context: LegacyContext): EnvironmentsPage {
  const seed = context.records()
  const names = environmentNames(seed)
  const now = context.now()
  return {
    environments: names.map((name) => environment(name, seed, now)),
    total_count: names.length,
  }
}

function systemDiagnostics(_: LegacyRequest, context: LegacyContext): SystemDiagnostics {
  const seed = context.records()
  const fileStores = environmentNames(seed).filter(hasFileStore)
  const version = seed.app.runtime_version
  const costs = seedHasCosts(seed)
  const pricing = { enabled: costs, unavailable_reason: costs ? null : ("not_configured" as const) }
  return {
    observed_at: iso(context.now()),
    deployment: {
      kind: "local",
      name: "development",
      name_status: "available",
      api_access: "open",
      dashboard_access: "open",
      dashboard_enabled: true,
      docs_enabled: true,
    },
    versions: { cayu: version, server_contract: CONTRACT.contract_version ?? "49" },
    capabilities: {
      ...CONTRACT.capabilities,
      cayu_version: version,
      surfaces: {
        ...CONTRACT.capabilities.surfaces,
        pricing: {
          configured: costs,
          read: pricing,
          mutate: { enabled: false, unavailable_reason: "unsupported" },
        },
      },
    },
    artifact_stores: {
      registrations: fileStores.map((name) => ({
        fingerprint: `sha256:${hex(storeOf(name), 64)}`,
        store_contract_operations: ["list", "read", "write", "delete"],
      })),
      total_count: fileStores.length,
      truncated: false,
    },
    pricing_catalog: costs
      ? {
          configured: true,
          metadata_status: "available",
          price_book_version: PRICE_BOOK,
          generated_at: seed.now,
        }
      : {
          configured: false,
          metadata_status: "not_configured",
          price_book_version: null,
          generated_at: null,
        },
  }
}

// ---------------------------------------------------------------------------------------
// Artifacts: files the agent saved. Each finished session leaves a Markdown report, and
// depending on what it did, a CSV of its tool results, a JSON result, a PNG chart or a
// large workspace archive. A few environments also hold shared files no session owns.

type StoredArtifact = {
  summary: ArtifactSummary
  /** The file's bytes, made on read so a large archive costs nothing until it's opened. */
  content: () => string | Uint8Array<ArrayBuffer>
}

const MAX_ARTIFACTS = 60

function csvCell(value: unknown): string {
  const raw = typeof value === "string" ? value : JSON.stringify(value)
  return /[",\n]/.test(raw) ? `"${raw.replaceAll('"', '""')}"` : raw
}

function report(s: SeedSession): string {
  const lines = [`# ${titleOf(s)}`, ""]
  if (s.overview.summary) lines.push(`**${s.overview.summary}**`, "")
  const request = firstRequest(s)
  if (request) lines.push("## Request", "", request, "")
  const reply = lastReply(s)
  if (reply) lines.push("## Findings", "", reply, "")
  const calls = toolCalls(s)
  if (calls.length) {
    lines.push(
      "## Evidence",
      "",
      ...calls.map((c) => `- ${c.tool}: ${String(c.result ?? "no result")}`),
      "",
    )
  }
  lines.push(`Produced by ${s.session.agent_name} in session ${s.session.id}.`, "")
  return lines.join("\n")
}

function evidenceCsv(s: SeedSession): string {
  const rows = toolCalls(s).map((c, i) =>
    [i + 1, c.tool, c.args, c.result ?? "", c.error ? "error" : "ok"].map(csvCell).join(","),
  )
  return ["step,tool,arguments,result,status", ...rows, ""].join("\n")
}

function resultJson(s: SeedSession): string {
  const output = structuredOutput(s)
  const result = {
    title: titleOf(s),
    specialist: s.session.agent_name,
    outcome: s.overview.state,
    summary: s.overview.summary,
    ...(output === undefined ? {} : { output }),
    steps: toolCalls(s).map((c) => ({ tool: c.tool, arguments: c.args, ok: !c.error })),
  }
  return `${JSON.stringify(result, null, 2)}\n`
}

const CRC_TABLE = Array.from({ length: 256 }, (_, n) => {
  let c = n
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
  return c >>> 0
})

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff
  for (const b of bytes) c = (CRC_TABLE[(c ^ b) & 0xff] ?? 0) ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

const u32 = (n: number) => [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff]

function pngChunk(type: string, data: Uint8Array): number[] {
  const body = new Uint8Array([...type].map((c) => c.charCodeAt(0)).concat([...data]))
  return [...u32(data.length), ...body, ...u32(crc32(body))]
}

/** A palette PNG with uncompressed (stored) zlib blocks: small code, real image bytes. */
function png(
  width: number,
  height: number,
  palette: number[],
  pixel: (x: number, y: number) => number,
): Uint8Array<ArrayBuffer> {
  const raw = new Uint8Array((width + 1) * height)
  for (let y = 0; y < height; y++)
    for (let x = 0; x < width; x++) raw[y * (width + 1) + 1 + x] = pixel(x, y)
  const zlib = [0x78, 0x01]
  for (let i = 0; i < raw.length; i += 65_535) {
    const len = Math.min(65_535, raw.length - i)
    zlib.push(i + len >= raw.length ? 1 : 0, len & 0xff, len >> 8, ~len & 0xff, (~len >> 8) & 0xff)
    for (const v of raw.subarray(i, i + len)) zlib.push(v)
  }
  let a = 1
  let b = 0
  for (const v of raw) {
    a = (a + v) % 65_521
    b = (b + a) % 65_521
  }
  zlib.push(...u32(((b << 16) | a) >>> 0))
  const plte = new Uint8Array(palette.flatMap((rgb) => [rgb >> 16, (rgb >> 8) & 0xff, rgb & 0xff]))
  const ihdr = new Uint8Array([...u32(width), ...u32(height), 8, 3, 0, 0, 0])
  return new Uint8Array([
    0x89,
    0x50,
    0x4e,
    0x47,
    0x0d,
    0x0a,
    0x1a,
    0x0a,
    ...pngChunk("IHDR", ihdr),
    ...pngChunk("PLTE", plte),
    ...pngChunk("IDAT", new Uint8Array(zlib)),
    ...pngChunk("IEND", new Uint8Array()),
  ])
}

/** A small bar chart, its bars derived from the session so each chart differs. */
function chartPng(s: SeedSession): Uint8Array<ArrayBuffer> {
  const [w, h, left, top, base] = [240, 140, 20, 12, 120]
  const values = Array.from({ length: 6 }, (_, i) =>
    Number.parseInt(hex(`${s.session.id}/bar${i}`, 2), 16),
  )
  const slot = (w - left - 10) / values.length
  return png(w, h, [0xffffff, 0xe5e7eb, 0x9ca3af, 0x3b82f6, 0xf59e0b], (x, y) => {
    if ((y === base && x >= left && x < w - 10) || (x === left && y >= top && y <= base)) return 2
    const i = Math.floor((x - left) / slot)
    const inBar = x > left && i < values.length && (x - left) % slot > 6 && (x - left) % slot < 28
    if (inBar && y < base && y >= base - (16 + ((values[i] ?? 0) % 90)))
      return i === values.length - 1 ? 4 : 3
    if ([39, 66, 93].includes(y) && x > left && x < w - 10) return 1
    return 0
  })
}

/** A deterministic stand-in for a workspace archive of `size` bytes. */
function archive(key: string, size: number): Uint8Array<ArrayBuffer> {
  const bytes = new Uint8Array(size)
  bytes.set([0x50, 0x4b, 0x03, 0x04])
  let h = Number.parseInt(hex(key, 8), 16)
  for (let i = 4; i < size; i++) {
    h = Math.imul(h ^ i, 16777619)
    bytes[i] = h >>> 24
  }
  return bytes
}

const bytesOf = (content: string | Uint8Array<ArrayBuffer>): Uint8Array<ArrayBuffer> =>
  typeof content === "string" ? new TextEncoder().encode(content) : content

function stored(
  summary: Omit<ArtifactSummary, "id" | "size_bytes" | "created_at" | "content_type">,
  contentType: string,
  createdAt: number,
  content:
    | string
    | Uint8Array<ArrayBuffer>
    | { size: number; bytes: () => Uint8Array<ArrayBuffer> },
): StoredArtifact {
  const owner = summary.session_id ?? summary.environment_name
  const lazy = typeof content === "object" && "size" in content ? content : null
  return {
    content: lazy ? lazy.bytes : () => content as string | Uint8Array<ArrayBuffer>,
    summary: {
      ...summary,
      id: `art_${hex(`${owner}/${summary.filename}`, 24)}`,
      content_type: contentType,
      size_bytes: lazy ? lazy.size : bytesOf(content as string | Uint8Array<ArrayBuffer>).length,
      created_at: iso(createdAt),
    },
  }
}

function sessionFiles(s: SeedSession, index: number): StoredArtifact[] {
  const environmentName = s.session.environment_name ?? "local"
  if (!hasFileStore(environmentName)) return []
  const name = slug(titleOf(s))
  const ended = Date.parse(s.overview.ended_at ?? s.overview.last_activity_at)
  const file = (
    filename: string,
    contentType: string,
    offsetMs: number,
    content: Parameters<typeof stored>[3],
  ) =>
    stored(
      {
        artifact_store_id: storeOf(environmentName),
        scope: "session",
        session_id: s.session.id,
        session_title: s.overview.title ?? null,
        agent_name: s.session.agent_name,
        environment_name: environmentName,
        filename,
        metadata: {
          workspace_path: `outputs/${filename}`,
          published_by: "publish_workspace_artifact",
        },
      },
      contentType,
      ended - offsetMs,
      content,
    )
  const files = [file(`${name}.md`, "text/markdown", 1_000, report(s))]
  if (toolCalls(s).length >= 2)
    files.push(file(`${name}-evidence.csv`, "text/csv", 0, evidenceCsv(s)))
  if (index % 2 === 0)
    files.push(file(`${name}-result.json`, "application/json", 2_000, resultJson(s)))
  if (index % 3 === 1) files.push(file(`${name}-chart.png`, "image/png", 3_000, chartPng(s)))
  if (index % 7 === 3) {
    const size = 2_200_000 + Number.parseInt(hex(s.session.id, 5), 16)
    const key = `${s.session.id}/archive`
    files.push(
      file(`${name}-workspace.zip`, "application/zip", 4_000, {
        size,
        bytes: () => archive(key, size),
      }),
    )
  }
  return files
}

/** Files kept at the environment level, readable by every session there. */
const SHARED_FILES: Record<
  string,
  Array<{ filename: string; contentType: string; daysAgo: number; text: string }>
> = {
  local: [
    {
      filename: "agent-handbook.md",
      contentType: "text/markdown",
      daysAgo: 12,
      text: "# Agent handbook\n\nNotes every session in this environment can read.\n\n- Cite the record you used for every number.\n- Ask before changing anything outside the workspace.\n",
    },
  ],
  checkout: [
    {
      filename: "review-checklist.md",
      contentType: "text/markdown",
      daysAgo: 9,
      text: "# Review checklist\n\n1. Does the change do what the description says?\n2. Are there tests for the new behavior?\n3. Could it break an existing caller?\n4. Is anything left that the author should clean up?\n",
    },
  ],
  sandbox: [
    {
      filename: "base-image.json",
      contentType: "application/json",
      daysAgo: 4,
      text: `${JSON.stringify(
        {
          image: "cayu/sandbox:2026.10.2",
          python: "3.13",
          node: "22",
          tools: ["git", "ripgrep", "uv"],
          network_allowlist: ["pypi.org", "registry.npmjs.org", "github.com"],
        },
        null,
        2,
      )}\n`,
    },
  ],
}

function environmentFiles(seed: AppSeed, now: number): StoredArtifact[] {
  if (!seed.sessions.length) return []
  return environmentNames(seed).flatMap((environmentName) =>
    (SHARED_FILES[environmentName] ?? []).map((f) =>
      stored(
        {
          artifact_store_id: storeOf(environmentName),
          scope: "environment",
          session_id: null,
          agent_name: null,
          environment_name: environmentName,
          filename: f.filename,
          metadata: { workspace_path: `shared/${f.filename}` },
        },
        f.contentType,
        now - f.daysAgo * 86_400_000,
        f.text,
      ),
    ),
  )
}

/** Newest first: the recent finished sessions' files and the environments' shared files. */
function allArtifacts(seed: AppSeed, now: number): StoredArtifact[] {
  const finished = seed.sessions
    .filter((s) => s.overview.state === "completed" && s.overview.ended_at)
    .sort((a, b) => (b.overview.ended_at ?? "").localeCompare(a.overview.ended_at ?? ""))
  return [...finished.flatMap(sessionFiles), ...environmentFiles(seed, now)]
    .sort((a, b) => b.summary.created_at.localeCompare(a.summary.created_at))
    .slice(0, MAX_ARTIFACTS)
}

export function findArtifact(
  { params, query }: Pick<LegacyRequest, "params" | "query">,
  context: LegacyContext,
): StoredArtifact {
  const store = query.get("artifact_store_id")
  const found = allArtifacts(context.records(), context.now()).find(
    (a) => a.summary.id === params.artifactId && (!store || a.summary.artifact_store_id === store),
  )
  if (!found) throw new HttpError(404, `Artifact ${params.artifactId} was not found.`)
  return found
}

function listArtifacts({ query }: LegacyRequest, context: LegacyContext): ArtifactsPage {
  const keys = [
    "session_id",
    "agent_name",
    "environment_name",
    "artifact_store_id",
    "scope",
  ] as const
  const matching = allArtifacts(context.records(), context.now())
    .map((a) => a.summary)
    .filter((a) => keys.every((key) => !query.get(key) || a[key] === query.get(key)))
  const needle = (query.get("q") ?? "").trim().toLowerCase()
  const order = query.get("order_by") ?? "created_at_desc"
  const rows = matching.filter(
    (a) =>
      !needle ||
      [
        a.filename,
        kindOf(a).label,
        a.content_type,
        a.agent_name,
        a.environment_name,
        a.session_title,
        a.id,
      ].some((value) => value?.toLowerCase().includes(needle)),
  )
  const primary = (a: ArtifactSummary) =>
    order.startsWith("filename_")
      ? a.filename.toLowerCase()
      : order.startsWith("size_bytes_")
        ? a.size_bytes
        : Date.parse(a.created_at)
  const compare = (a: string | number, b: string | number) => (a < b ? -1 : a > b ? 1 : 0)
  rows.sort(
    (a, b) =>
      (order.endsWith("_desc") ? -1 : 1) *
      (compare(primary(a), primary(b)) ||
        compare(a.artifact_store_id ?? "", b.artifact_store_id ?? "") ||
        compare(a.id, b.id)),
  )
  const limit = integer(query, "limit", 50)
  const offset = integer(query, "offset", 0)
  const more = offset + limit < rows.length
  return {
    artifacts: rows.slice(offset, offset + limit),
    total_count: rows.length,
    limit,
    offset,
    truncated: more,
    next_offset: more ? offset + limit : null,
  }
}

function base64(bytes: Uint8Array): string {
  let binary = ""
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary)
}

function readArtifact(request: LegacyRequest, context: LegacyContext): ArtifactRead {
  const artifact = findArtifact(request, context)
  const content = artifact.content()
  const bytes = bytesOf(content)
  const preview = bytes.slice(0, integer(request.query, "max_bytes", 65_536))
  return {
    artifact: artifact.summary,
    preview_base64: base64(preview),
    text_preview: typeof content === "string" ? new TextDecoder().decode(preview) : null,
    total_bytes: bytes.length,
    truncated: preview.length < bytes.length,
  }
}

function artifactContent(request: LegacyRequest, context: LegacyContext): Response {
  const { summary, content } = findArtifact(request, context)
  const body = content()
  const disposition = request.query.get("disposition") === "attachment" ? "attachment" : "inline"
  return new Response(bytesOf(body), {
    headers: {
      "Content-Type":
        typeof body === "string" ? `${summary.content_type}; charset=utf-8` : summary.content_type,
      "Content-Disposition": `${disposition}; filename="${summary.filename}"`,
    },
  })
}

/** The Inbox's child actions: no seed delegates tool calls, so the page is always empty. */
function pendingActions(): PendingActionsPage {
  return {
    actions: [],
    issues: [],
    has_more: false,
    next_cursor: null,
    total_count: 0,
    inspected_candidate_count: 0,
  }
}

// ---------------------------------------------------------------------------------------

export const coreRoutes: LegacyRoute[] = [
  { method: "GET", path: "/pending-actions", handle: pendingActions },
  { method: "GET", path: "/system/diagnostics", handle: systemDiagnostics },
  { method: "GET", path: "/environments", handle: environments },
  { method: "GET", path: "/artifacts", handle: listArtifacts },
  { method: "GET", path: "/artifacts/:artifactId", handle: readArtifact },
  { method: "GET", path: "/artifacts/:artifactId/content", handle: artifactContent },
  { method: "POST", path: "/operations/snapshot", handle: operationsSnapshot },
  { method: "POST", path: "/sessions/summary", handle: sessionsSummary },
  { method: "POST", path: "/usage/rollup", handle: usageRollup },
  { method: "GET", path: "/tasks", handle: listTasks },
  {
    method: "GET",
    path: "/tasks/:taskId",
    handle: ({ params }, context) => taskInfo(context, params.taskId ?? ""),
  },
  {
    method: "GET",
    path: "/tasks/:taskId/schedule/events",
    handle: ({ params }, context) => scheduleEvents(context, params.taskId ?? ""),
  },
  ...(
    [
      ["pause", "paused"],
      ["block", "blocked"],
      ["needs-attention", "needs_attention"],
    ] as const
  ).map(
    ([path, status]): LegacyRoute => ({
      method: "POST",
      path: `/tasks/:taskId/${path}`,
      handle: ({ params, body }, context) =>
        holdTask(context, params.taskId ?? "", status, record(body)),
    }),
  ),
  {
    method: "POST",
    path: "/tasks/:taskId/resume",
    handle: ({ params }, context) => resumeTask(context, params.taskId ?? ""),
  },
]
