import assert from "node:assert/strict"
import { test } from "vite-plus/test"
import {
  groupOf,
  holdable,
  isCayuTask,
  replayUnavailableText,
  statusLine,
  when,
} from "../src/next/app/task-model.ts"

process.env.TZ = "UTC"
const NOW = Date.parse("2026-10-21T23:30:00Z")
const min = 60_000
const iso = (ms) => new Date(ms).toISOString()
const task = (over = {}) => ({
  id: "t1",
  type: "close_books",
  title: "Close October books",
  status: "pending",
  status_reason: null,
  session_id: null,
  parent_task_id: null,
  available_at: null,
  retry_series: null,
  schedule: null,
  prerequisite_task_ids: [],
  ...over,
})

test("statuses fall into five groups", () => {
  assert.equal(groupOf("claimed"), "active")
  assert.equal(groupOf("waiting_dependencies"), "waiting")
  assert.equal(groupOf("needs_attention"), "held")
  assert.equal(groupOf("dependency_skipped"), "failed")
  assert.equal(groupOf("cancelled"), "done")
})

test("near times are relative, later ones the viewer clock time", () => {
  assert.equal(when(NOW + 6 * min, NOW), "in 6m")
  assert.equal(when(NOW - 5_000, NOW), "just now")
  assert.equal(when(NOW + 2 * 60 * min, NOW), "Oct 22, 1:30 AM")
  assert.equal(when(Date.parse("2026-11-01T14:00:00Z"), NOW), "Nov 1, 2:00 PM")
})

test("waiting on prerequisites counts the ones not completed", () => {
  const all = [
    task({ id: "a", status: "completed" }),
    task({ id: "b", status: "running" }),
    task({ id: "c", status: "pending" }),
  ]
  const t = task({ status: "waiting_dependencies", prerequisite_task_ids: ["a", "b", "c"] })
  assert.equal(statusLine(t, [...all, t], NOW), "Waiting on 2 tasks")
})

test("pending tasks say when they start", () => {
  assert.equal(statusLine(task(), [], NOW), "Queued")
  const later = task({ available_at: iso(Date.parse("2026-11-01T14:00:00Z")), schedule: {} })
  assert.equal(statusLine(later, [], NOW), "Scheduled for Nov 1, 2:00 PM")
  const retry = task({
    available_at: iso(NOW + 6 * min),
    retry_series: { attempt: 2, next_eligible_at: iso(NOW + 6 * min), policy: { max_attempts: 3 } },
  })
  assert.equal(statusLine(retry, [], NOW), "Retry 2 of 3 in 6m")
})

test("holds and failures carry their reason; a retried failure points at the retry", () => {
  const blocked = task({ status: "blocked", status_reason: "Vendor file is late." })
  assert.equal(statusLine(blocked, [], NOW), "Blocked: Vendor file is late.")
  const next = task({ id: "t2", retry_series: { attempt: 2, policy: { max_attempts: 3 } } })
  const failed = task({
    status: "failed",
    status_reason: "rate limited",
    retry_series: { attempt: 1, successor_task_id: "t2", policy: { max_attempts: 3 } },
  })
  assert.equal(statusLine(failed, [failed, next], NOW), "Failed · attempt 2 queued")
  assert.equal(
    statusLine(task({ status: "failed", status_reason: "boom" }), [], NOW),
    "Failed: boom",
  )
})

test("a failure says why with its error summary, over a status code", () => {
  const summary = "GitError: couldn't find remote ref refs/pull/217/head"
  assert.equal(
    statusLine(task({ status: "failed", error_summary: summary }), [], NOW),
    `Failed: ${summary}`,
  )
  // A retry series' failed attempt carries a disposition code as its status reason.
  const exhausted = task({
    status: "failed",
    status_reason: "attempts_exhausted",
    error_summary: summary,
    retry_series: { attempt: 3, policy: { max_attempts: 3 } },
  })
  assert.equal(statusLine(exhausted, [exhausted], NOW), `Failed: ${summary}`)
  assert.equal(
    statusLine(task({ status: "failed", status_reason: null, error_summary: null }), [], NOW),
    "Failed",
  )
})

test("Run again says in words why it can't start a task", () => {
  assert.equal(
    replayUnavailableText("task_type_not_declared"),
    "Can't run this task again. Only the agent's code starts tasks of this type; it isn't one you can create here.",
  )
  assert.equal(
    replayUnavailableText("specialist_unavailable"),
    "Can't run this task again. The specialist that runs it isn't available.",
  )
  for (const reason of [null, undefined, "some_future_code"])
    assert.equal(
      replayUnavailableText(reason),
      "Can't run this task again. Its original run can't be found.",
    )
})

test("running tasks count their subtasks", () => {
  const parent = task({ status: "running" })
  const kids = [task({ id: "k1", parent_task_id: "t1" }), task({ id: "k2", parent_task_id: "t1" })]
  assert.equal(statusLine(parent, [parent, ...kids], NOW), "Running · 2 subtasks")
})

test("Cayu's own tasks and what can be held", () => {
  assert.equal(isCayuTask({ type: "cayu.dispatch" }), true)
  assert.equal(isCayuTask({ type: "close_books" }), false)
  assert.equal(holdable(task()), true)
  assert.equal(holdable(task({ status: "running", session_id: "s1" })), false)
  assert.equal(holdable(task({ status: "blocked" })), false)
  assert.equal(holdable(task({ status: "completed" })), false)
})

test("failed retries increment the predecessor only when the successor has no attempt", () => {
  for (const [priorAttempt, nextAttempt, expected] of [
    [1, null, 2],
    [3, null, 4],
    [undefined, null, 2],
    [3, 8, 8],
  ]) {
    const next = task({
      id: "retry",
      retry_series: nextAttempt === null ? null : { attempt: nextAttempt },
    })
    const prior = task({
      status: "failed",
      retry_series: { attempt: priorAttempt, successor_task_id: "retry" },
    })
    assert.equal(statusLine(prior, [prior, next], NOW), `Failed · attempt ${expected} queued`)
  }
  assert.equal(statusLine(task({ status: "failed", retry_series: null }), [], NOW), "Failed")
})

test("handler deadline failure is explicit without inferring from ordinary text", () => {
  assert.equal(
    statusLine(
      task({
        status: "failed",
        error: { error: "ExecutionDeadlineExceeded", scope: "task_handler" },
      }),
      [],
      NOW,
    ),
    "Task handler ran out of time",
  )
  assert.equal(
    statusLine(
      task({ status: "failed", error: { error: "ExecutionDeadlineExceeded", scope: "other" } }),
      [],
      NOW,
    ),
    "Failed",
  )
})

test("missing prerequisite observations never become an exact unfinished count", () => {
  const waiting = task({ status: "waiting_dependencies", prerequisite_task_ids: ["done", "open"] })
  const open = task({ id: "open" })
  assert.equal(
    statusLine(waiting, [waiting, open], NOW, undefined, false),
    "Waiting on prerequisites",
  )
  assert.equal(
    statusLine(
      waiting,
      [waiting, open, task({ id: "done", status: "completed" })],
      NOW,
      undefined,
      false,
    ),
    "Waiting on 1 task",
  )
})
